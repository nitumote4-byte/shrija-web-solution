/**
 * MAIN-world: delete/reset saved Article Weight Details rows
 * when the portal UI has no Delete button.
 */
(() => {
  if (window.__SHRIJA_DELETE_API__ && window.__SHRIJA_DELETE_API__.__v >= 4) return;

  const STORAGE_URL = "SHRIJA_WEIGHT_URL";
  const STORAGE_BODY = "SHRIJA_WEIGHT_BODY_SAMPLE";

  function installDialogs() {
    window.alert = () => {};
    window.confirm = () => true;
    window.prompt = (_m, d) => (d == null ? "" : String(d));
  }

  function remember(url, body) {
    try {
      const blob = `${url || ""} ${body || ""}`;
      if (!/weight|ahc|article|weigh|huid|job|save|delete|remove|reset/i.test(blob)) return;
      const u = String(url || "");
      if (/\.min\.js|\.css|dataTables|buttons\.|jquery|bootstrap/i.test(u)) return;
      if (
        /list|get|fetch|load|detail|datatable/i.test(u) &&
        !/save|delete|remove|update|reset|clear|insert|edit/i.test(blob)
      ) {
        return;
      }
      sessionStorage.setItem(STORAGE_URL, String(url));
      if (body != null && String(body).length) {
        sessionStorage.setItem(STORAGE_BODY, String(body).slice(0, 1200));
      }
    } catch {
      /* ignore */
    }
  }

  function ensureSpy() {
    if (window.__SHRIJA_AJAX_SPY__) return;
    window.__SHRIJA_AJAX_SPY__ = true;
    try {
      const $ = window.jQuery || window.$;
      if ($ && $.ajaxPrefilter) {
        $(document).ajaxSend((_e, _x, settings) => {
          remember(settings.url, settings.data);
        });
      }
    } catch {
      /* ignore */
    }
    try {
      const XO = XMLHttpRequest.prototype.open;
      const XS = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function (method, url) {
        this.__shrijaUrl = url;
        this.__shrijaMethod = method;
        return XO.apply(this, arguments);
      };
      XMLHttpRequest.prototype.send = function (body) {
        try {
          const m = String(this.__shrijaMethod || "GET").toUpperCase();
          if (m !== "GET" || /delete|remove|save|update|weight|article/i.test(String(this.__shrijaUrl || ""))) {
            remember(this.__shrijaUrl, body);
          }
        } catch {
          /* ignore */
        }
        return XS.apply(this, arguments);
      };
    } catch {
      /* ignore */
    }
  }

  function absUrl(u) {
    if (!u) return null;
    u = String(u).trim().replace(/^['"`]|['"`]$/g, "");
    if (!u || /[<>{}]/.test(u)) return null;
    if (/^https?:\/\//i.test(u)) return u;
    if (u.startsWith("/")) return location.origin + u;
    if (u.startsWith("MANAK/")) return `${location.origin}/${u}`;
    if (/^UID_|^[A-Za-z0-9_]+$/i.test(u)) return `${location.origin}/MANAK/${u}`;
    try {
      return new URL(u, location.href).href;
    } catch {
      return `${location.origin}/MANAK/${u}`;
    }
  }

  function looksSuccess(resp) {
    const t = String(resp == null ? "" : resp).trim();
    if (!t) return true;
    const low = t.toLowerCase();
    if (/timeout|whitelabel|404|500 |access denied|unauthorized|exception/.test(low)) return false;
    if (/fail|invalid|denied|not\s*allow|error/.test(low) && !/success|saved|deleted|removed|ok\b/.test(low)) {
      return false;
    }
    if (/success|saved|deleted|removed|updated|ok\b|"status"\s*:\s*1|"status"\s*:\s*"ok"/.test(low)) {
      return true;
    }
    if (/^(1|y|yes|ok|true)$/i.test(t)) return true;
    if (t.length < 120 && !/<(html|body|script)/i.test(t)) return true;
    return false;
  }

  function httpPost(url, data, timeoutMs = 8000) {
    const $ = window.jQuery || window.$;
    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => {
        if (done) return;
        done = true;
        resolve(v);
      };
      setTimeout(() => finish({ ok: false, resp: "timeout" }), timeoutMs);

      if ($) {
        $.ajax({
          url,
          type: "POST",
          data,
          timeout: timeoutMs,
          traditional: true,
          success: (resp) => finish({ ok: true, resp }),
          error: (xhr) =>
            finish({ ok: false, status: xhr?.status || 0, resp: xhr?.responseText || "error" }),
        });
        return;
      }

      const body = new URLSearchParams();
      Object.keys(data || {}).forEach((k) => {
        const v = data[k];
        if (v !== undefined && v !== null && v !== "") body.append(k, String(v));
      });
      fetch(url, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body,
      })
        .then((r) => r.text().then((text) => finish({ ok: r.ok, status: r.status, resp: text })))
        .catch((e) => finish({ ok: false, resp: String(e) }));
    });
  }

  async function harvestUrlsFromRemoteScripts(push) {
    const srcs = Array.from(document.querySelectorAll("script[src]"))
      .map((s) => s.src)
      .filter((src) => {
        try {
          const u = new URL(src, location.href);
          return u.origin === location.origin && !/\.min\.js$/i.test(u.pathname);
        } catch {
          return false;
        }
      })
      .slice(0, 20);

    await Promise.all(
      srcs.map(async (src) => {
        try {
          const res = await fetch(src, { credentials: "include", cache: "force-cache" });
          if (!res.ok) return;
          const text = await res.text();
          if (!/weight|ahc|UID_|weigh|article/i.test(text)) return;
          const re = /['"`]((?:\/MANAK\/)?UID_[A-Za-z0-9_]+)['"`]/g;
          let m;
          while ((m = re.exec(text))) push(m[1]);
          // url: '...' patterns near weight/save
          const re2 =
            /(?:url|URL|action|href)\s*[:=]\s*['"`]([^'"`]*(?:Weight|weight|AHC|Article|Weigh)[^'"`]*)['"`]/g;
          while ((m = re2.exec(text))) push(m[1]);
        } catch {
          /* ignore */
        }
      })
    );
  }

  async function harvestCandidateUrlsAsync() {
    const urls = [];
    const push = (u) => {
      const a = absUrl(u);
      if (!a || urls.includes(a)) return;
      if (/\.min\.js|\.css|dataTables|jquery|bootstrap|buttons\.|print\.|select\./i.test(a)) return;
      urls.push(a);
    };

    // Sync harvest first
    harvestCandidateUrls().forEach(push);
    emitProgress("Page scripts se weight API dhoondh rahe hain…");
    await harvestUrlsFromRemoteScripts(push);

    // Full page HTML sweep (onclick templates often live here)
    try {
      const html = document.documentElement.innerHTML;
      const re = /['"`]((?:\/MANAK\/)?UID_[A-Za-z0-9_]*[Ww]eight[A-Za-z0-9_]*)['"`]/g;
      let m;
      while ((m = re.exec(html))) push(m[1]);
      const re2 = /['"`]((?:\/MANAK\/)?UID_[A-Za-z0-9_]*(?:Delete|Remove|Save|Update)[A-Za-z0-9_]*)['"`]/g;
      while ((m = re2.exec(html))) push(m[1]);
    } catch {
      /* ignore */
    }

    // Prioritize delete/save names
    urls.sort((a, b) => {
      const score = (u) => {
        let s = 0;
        if (/delete|remove|clear|reset/i.test(u)) s += 5;
        if (/save|update/i.test(u)) s += 3;
        if (/weight|article|ahc/i.test(u)) s += 2;
        if (/list|get|fetch|load|detail/i.test(u)) s -= 2;
        return s;
      };
      return score(b) - score(a);
    });

    return urls.slice(0, 16);
  }

  function harvestCandidateUrls() {
    const urls = [];
    const push = (u) => {
      const a = absUrl(u);
      if (!a || urls.includes(a)) return;
      if (/\.min\.js|\.css|dataTables|jquery|bootstrap|buttons\.|print\.|select\./i.test(a)) return;
      urls.push(a);
    };

    try {
      push(sessionStorage.getItem(STORAGE_URL));
    } catch {
      /* ignore */
    }

    try {
      const $ = window.jQuery || window.$;
      if ($ && $.fn?.dataTable) {
        $("table").each(function () {
          try {
            if (!$.fn.dataTable.isDataTable(this)) return;
            const settings = $(this).DataTable().settings()[0];
            const ajax = settings?.ajax;
            let url = null;
            if (typeof ajax === "string") url = ajax;
            else if (ajax && typeof ajax.url === "string") url = ajax.url;
            if (url) {
              push(url);
              const leaf = String(url).replace(/\?.*$/, "").split("/").pop() || "";
              const dir = String(absUrl(url)).replace(/[^/]+$/, "");
              [
                leaf.replace(/List|Get|Fetch|Load|Details|Data|Pending|Weighed|Capture/gi, "Delete"),
                leaf.replace(/List|Get|Fetch|Load|Details|Data|Pending|Weighed|Capture/gi, "Remove"),
                leaf.replace(/List|Get|Fetch|Load|Details|Data|Pending|Weighed|Capture/gi, "Save"),
                "UID_DeleteArticleWeight",
                "UID_SaveArticleWeight",
                "UID_RemoveArticleWeight",
                "UID_DeleteWeight",
                "UID_SaveWeight",
              ].forEach((n) => {
                if (n && n !== leaf) push(dir + n);
              });
            }
            const cols = settings?.aoColumns || [];
            cols.forEach((c) => {
              const blob = `${c?.mRender || ""} ${c?.render || ""} ${c?.sDefaultContent || ""}`;
              const m = String(blob).match(/UID_[A-Za-z0-9_]+/g);
              if (m) m.forEach(push);
            });
          } catch {
            /* ignore */
          }
        });
      }
    } catch {
      /* ignore */
    }

    document.querySelectorAll("a, button, input[type='button'], [onclick]").forEach((el) => {
      const blob = `${el.getAttribute("onclick") || ""} ${el.getAttribute("href") || ""} ${el.dataset?.url || ""}`;
      const m = blob.match(/['"`]((?:\/MANAK\/|UID_)[^'"`]+)['"`]/i);
      if (m) push(m[1]);
      const m2 = blob.match(/\b(UID_[A-Za-z0-9_]+)\b/);
      if (m2) push(m2[1]);
    });

    document.querySelectorAll("script").forEach((s) => {
      const t = s.textContent || "";
      if (!/weight|ahc|article|UID_/i.test(t)) return;
      const re = /['"`]((?:\/MANAK\/)?UID_[A-Za-z0-9_]+)['"`]/g;
      let m;
      while ((m = re.exec(t))) push(m[1]);
    });

    const base = `${location.origin}/MANAK/`;
    [
      "UID_DeleteArticleWeight",
      "UID_RemoveArticleWeight",
      "UID_DeleteWeight",
      "UID_ClearArticleWeight",
      "UID_ResetArticleWeight",
      "UID_DeleteWeighedArticle",
      "UID_SaveArticleWeight",
      "UID_saveArticleWeight",
      "UID_SaveWeight",
      "UID_UpdateArticleWeight",
      "UID_EditArticleWeight",
    ].forEach((n) => push(base + n));

    return urls.slice(0, 16);
  }

  function decodeParam(value) {
    if (!value) return "";
    try {
      const decoded = atob(value);
      if (/^\d+$/.test(decoded)) return decoded;
    } catch {
      /* ignore */
    }
    return value;
  }

  function jobRequestFromPage() {
    const params = new URLSearchParams(location.search);
    return {
      jobNo: decodeParam(params.get("jobNo") || ""),
      requestNo: decodeParam(params.get("requestNo") || ""),
    };
  }

  function headerMap(table) {
    const map = {};
    const row =
      table.querySelector("thead tr") ||
      Array.from(table.querySelectorAll("tr")).find((tr) => tr.querySelector("th"));
    if (!row) return map;
    Array.from(row.children).forEach((cell, i) => {
      const h = String(cell.textContent || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
      if (h.includes("ahc")) map.ahc = i;
      else if (h.includes("weight")) map.weight = i;
      else if (h.includes("huid")) map.huid = i;
    });
    return map;
  }

  function scrapeDetails() {
    const out = [];
    document.querySelectorAll("table").forEach((table) => {
      if (
        table.querySelector(
          'input[placeholder*="Scan weight" i], input[placeholder*="weight" i]'
        )
      ) {
        return;
      }
      const map = headerMap(table);
      if (map.ahc == null || map.weight == null) return;
      const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
        String(th.textContent || "")
          .trim()
          .toLowerCase()
      );
      if (headers.some((h) => h === "save" || h.includes("save"))) return;

      table.querySelectorAll("tbody tr").forEach((tr) => {
        const text = String(tr.textContent || "").toLowerCase();
        if (!text || text.includes("no data available")) return;
        const cells = tr.querySelectorAll("td");
        if (cells.length < 2) return;
        const ahcTag = String(cells[map.ahc]?.textContent || "").trim();
        if (!/^\d+$/.test(ahcTag)) return;
        const huid = map.huid != null ? String(cells[map.huid]?.textContent || "").trim() : "";
        const weight = String(cells[map.weight]?.textContent || "")
          .replace(/,/g, "")
          .trim();
        out.push({ ahcTag, huid, weight });
      });
    });
    return out;
  }

  function isStillInDetails(ahcTag) {
    return scrapeDetails().some((r) => String(r.ahcTag) === String(ahcTag));
  }

  function isInCapture(ahcTag) {
    const tag = String(ahcTag);
    for (const table of document.querySelectorAll("table")) {
      const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
        String(th.textContent || "")
          .trim()
          .toLowerCase()
      );
      if (!headers.some((h) => h === "save" || h.includes("save"))) continue;
      const map = headerMap(table);
      for (const tr of table.querySelectorAll("tbody tr")) {
        const cells = tr.querySelectorAll("td");
        const ahc =
          map.ahc != null
            ? String(cells[map.ahc]?.textContent || "").trim()
            : String(cells[1]?.textContent || "").trim();
        if (ahc !== tag) continue;
        const input = tr.querySelector(
          'input[placeholder*="Scan weight" i], input[placeholder*="weight" i], input[type="text"], input[type="number"]'
        );
        if (input && !input.disabled) return true;
      }
    }
    return false;
  }

  function bodyVariants(row, jr) {
    // Minimal + common Manak/BIS field names
    return [
      {
        ahcTag: row.ahcTag,
        huid: row.huid,
        jobNo: jr.jobNo,
        requestNo: jr.requestNo,
        weight: "0",
        Weight: "0",
        action: "delete",
        flag: "D",
      },
      {
        ahcTag: row.ahcTag,
        AHC_Tag: row.ahcTag,
        ahcNo: row.ahcTag,
        huid: row.huid,
        HUID: row.huid,
        jobNo: jr.jobNo,
        jobCardNo: jr.jobNo,
        jobCardNumber: jr.jobNo,
        requestNo: jr.requestNo,
        requestNumber: jr.requestNo,
        weight: "0",
        Weight: "0",
        articleWeight: "0",
      },
      {
        ahcTag: row.ahcTag,
        jobNo: jr.jobNo,
        requestNo: jr.requestNo,
        weight: 0,
      },
      {
        ahcNo: row.ahcTag,
        huidNo: row.huid,
        jobCardNo: jr.jobNo,
        requestNo: jr.requestNo,
        articleWt: "0",
        status: "D",
      },
    ];
  }

  function reloadTables() {
    try {
      const $ = window.jQuery;
      if (!$ || !$.fn?.dataTable) return;
      $("table").each(function () {
        if (!$.fn.dataTable.isDataTable(this)) return;
        try {
          $(this).DataTable().ajax.reload(null, false);
        } catch {
          try {
            $(this).DataTable().draw(false);
          } catch {
            /* ignore */
          }
        }
      });
    } catch {
      /* ignore */
    }
  }

  function emitProgress(msg) {
    try {
      document.documentElement.setAttribute("data-shrija-del-progress", String(msg || ""));
    } catch {
      /* ignore */
    }
  }

  async function discoverWorkingCombo(row, urls, jr) {
    emitProgress(`API discover for AHC ${row.ahcTag}…`);
    const fnNames = [
      "deleteArticleWeight",
      "DeleteArticleWeight",
      "removeArticleWeight",
      "resetArticleWeight",
      "clearArticleWeight",
      "saveArticleWeight",
      "SaveArticleWeight",
      "saveWeight",
      "SaveWeight",
    ];
    for (const name of fnNames) {
      const fn = window[name];
      if (typeof fn !== "function") continue;
      try {
        emitProgress(`Trying page fn ${name}…`);
        const ret = fn(row.ahcTag, 0, jr.jobNo, jr.requestNo, row.huid);
        await Promise.resolve(ret).catch(() => {});
        await new Promise((r) => setTimeout(r, 350));
        reloadTables();
        await new Promise((r) => setTimeout(r, 300));
        if (!isStillInDetails(row.ahcTag) || isInCapture(row.ahcTag)) {
          return { ok: true, via: `fn:${name}`, body: null };
        }
      } catch {
        /* next */
      }
    }

    const bodies = bodyVariants(row, jr);
    let attempts = 0;
    const maxAttempts = 24; // hard cap
    for (const url of urls) {
      for (const data of bodies) {
        if (attempts++ >= maxAttempts) {
          return { ok: false };
        }
        emitProgress(`Try ${attempts}/${maxAttempts}: ${String(url).replace(/^.*\/MANAK\//, "")}`);
        const res = await httpPost(url, data, 4000);
        if (!res.ok && !looksSuccess(res.resp)) continue;
        reloadTables();
        await new Promise((r) => setTimeout(r, 400));
        if (!isStillInDetails(row.ahcTag) || isInCapture(row.ahcTag)) {
          return { ok: true, via: url, body: data };
        }
      }
    }
    return { ok: false };
  }

  async function deleteWithKnown(row, via, body, jr) {
    if (String(via).startsWith("fn:")) {
      const name = String(via).slice(3);
      const fn = window[name];
      if (typeof fn !== "function") return false;
      try {
        const ret = fn(row.ahcTag, 0, jr.jobNo, jr.requestNo, row.huid);
        await Promise.resolve(ret).catch(() => {});
      } catch {
        return false;
      }
    } else {
      const data =
        body ||
        bodyVariants(row, jr)[0];
      // Rebind ahc/huid for this row
      const payload = {
        ...data,
        ahcTag: row.ahcTag,
        AHC_Tag: row.ahcTag,
        ahc: row.ahcTag,
        huid: row.huid,
        HUID: row.huid,
      };
      const res = await httpPost(via, payload, 4000);
      if (!res.ok && !looksSuccess(res.resp)) return false;
    }
    reloadTables();
    await new Promise((r) => setTimeout(r, 350));
    return !isStillInDetails(row.ahcTag) || isInCapture(row.ahcTag);
  }

  async function deleteAll(filterAhcs) {
    installDialogs();
    ensureSpy();
    const jr = jobRequestFromPage();
    emitProgress("Harvesting weight API URLs…");
    const urls = await harvestCandidateUrlsAsync();
    let rows = scrapeDetails();
    if (filterAhcs && filterAhcs.length) {
      const set = new Set(filterAhcs.map(String));
      rows = rows.filter((r) => set.has(String(r.ahcTag)));
    }

    if (!rows.length) {
      return { ok: false, deleted: 0, failed: [], left: 0, urlsTried: urls.length };
    }

    let deleted = 0;
    const failed = [];
    let workingVia = null;
    let workingBody = null;

    // Discover once on first row
    const first = rows[0];
    emitProgress(`Discovering delete API (${rows.length} rows, ${urls.length} urls)…`);
    const discovered = await discoverWorkingCombo(first, urls, jr);
    if (discovered.ok) {
      deleted++;
      workingVia = discovered.via;
      workingBody = discovered.body;
      emitProgress(`API mil gaya. Deleted AHC ${first.ahcTag}. Rest delete…`);
    } else {
      failed.push(first.ahcTag);
      emitProgress("API discover fail — Capture pe Save seekhne ki zarurat ho sakti hai.");
      return {
        ok: false,
        deleted: 0,
        failed: rows.map((r) => r.ahcTag),
        left: scrapeDetails().length,
        urlsTried: urls.length,
        learnedUrl: null,
        hint: "Capture empty + portal pe Delete nahi. Is job se saved weights extension delete nahi kar sakti jab tak Manak Save API na mile. Dusri job me Capture Save ek baar dabao (API seekhne), ya BIS support se reset karo.",
      };
    }

    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      emitProgress(`Deleting AHC ${row.ahcTag} (${i + 1}/${rows.length})…`);
      const ok = await deleteWithKnown(row, workingVia, workingBody, jr);
      if (ok) deleted++;
      else {
        // One rediscover attempt
        const again = await discoverWorkingCombo(row, urls, jr);
        if (again.ok) {
          deleted++;
          workingVia = again.via;
          workingBody = again.body;
        } else {
          failed.push(row.ahcTag);
        }
      }
    }

    return {
      ok: deleted > 0,
      deleted,
      failed,
      left: scrapeDetails().length,
      urlsTried: urls.length,
      learnedUrl: (() => {
        try {
          return sessionStorage.getItem(STORAGE_URL);
        } catch {
          return null;
        }
      })(),
      via: workingVia,
    };
  }

  // Learn URL when a Capture Save is clicked
  document.addEventListener(
    "click",
    (e) => {
      const btn = e.target?.closest?.("button, a, input[type='button'], input[type='submit']");
      if (!btn) return;
      const t = `${btn.textContent || ""} ${btn.value || ""}`.toLowerCase();
      if (!/\bsave\b/.test(t)) return;
      ensureSpy();
    },
    true
  );

  installDialogs();
  ensureSpy();

  window.__SHRIJA_DELETE_API__ = {
    __v: 4,
    deleteAll,
    harvestCandidateUrls,
    scrapeDetails,
  };
})();
