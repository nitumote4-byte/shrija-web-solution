/**
 * MAIN-world hook (document_start).
 * Blocks Web Serial "Scan weight" port picker + auto-accepts alert/confirm.
 */
(() => {
  if (window.__SHRIJA_PAGE_HOOK__) return;
  window.__SHRIJA_PAGE_HOOK__ = true;

  window.alert = () => {};
  window.confirm = () => true;
  window.prompt = (_m, d) => (d == null ? "" : String(d));

  const blockSerial = () => {
    try {
      if (!navigator.serial) return;
      const blocked = () =>
        Promise.reject(new DOMException("Blocked by Shrija Weight Capture", "NotAllowedError"));
      try {
        Object.defineProperty(navigator.serial, "requestPort", {
          configurable: true,
          writable: true,
          value: blocked,
        });
      } catch {
        navigator.serial.requestPort = blocked;
      }
      try {
        Object.defineProperty(navigator.serial, "getPorts", {
          configurable: true,
          writable: true,
          value: async () => [],
        });
      } catch {
        navigator.serial.getPorts = async () => [];
      }
    } catch {
      /* ignore */
    }
  };

  blockSerial();

  // Re-apply if page scripts redefine navigator.serial later
  const reblock = () => blockSerial();
  document.addEventListener("focusin", reblock, true);
  document.addEventListener("click", reblock, true);
  document.addEventListener("mousedown", reblock, true);

  try {
    const desc = Object.getOwnPropertyDescriptor(Navigator.prototype, "serial");
    if (desc?.get) {
      const originalGet = desc.get;
      Object.defineProperty(Navigator.prototype, "serial", {
        configurable: true,
        enumerable: desc.enumerable,
        get() {
          const serial = originalGet.call(this);
          if (serial) {
            try {
              serial.requestPort = () =>
                Promise.reject(
                  new DOMException("Blocked by Shrija Weight Capture", "NotAllowedError")
                );
              serial.getPorts = async () => [];
            } catch {
              /* ignore */
            }
          }
          return serial;
        },
      });
    }
  } catch {
    /* ignore */
  }
})();
