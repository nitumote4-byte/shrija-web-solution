(() => {
  if (window.__SHRIJA_WC_LOADED__) return;
  window.__SHRIJA_WC_LOADED__ = true;

  const ROOT_ID = "shrija-wc-root";
  /** Short pause after Save for AJAX row refresh */
  const SAVE_DELAY_MS = 220;
  /** Max wait for OK dialogs; exits early when quiet */
  const DIALOG_WAIT_MS = 450;
  const DIALOG_QUIET_MS = 140;

  /** @type {{ ahcTag: string, weight: number, jobNo: string, requestNo: string }[]} */
  let pendingRows = [];
  let selectedFileName = "";
  let licenseOk = false;
  let autoDialogActive = false;
  let dialogObserver = null;

  const CONTEXT_MSG =
    "Extension reload ho chuki hai, is page ka purana script disconnect ho gaya. Weighing Desk tab par Ctrl+F5 karo. Panel par v1.3.1 dikhe, phir Process dubara chalao.";

  function runtimeAlive() {
    try {
      return !!(chrome.runtime && chrome.runtime.id);
    } catch {
      return false;
    }
  }

  function sendRuntime(message) {
    return new Promise((resolve) => {
      if (!runtimeAlive()) {
        resolve({ ok: false, error: CONTEXT_MSG });
        return;
      }
      try {
        chrome.runtime.sendMessage(message, (res) => {
          let lastError = "";
          try {
            lastError = chrome.runtime.lastError?.message || "";
          } catch (err) {
            lastError = String(err && err.message ? err.message : err);
          }
          if (lastError) {
            resolve({
              ok: false,
              error: /invalidated|context/i.test(lastError) ? CONTEXT_MSG : lastError,
            });
            return;
          }
          resolve(res || { ok: false });
        });
      } catch (err) {
        const text = String(err && err.message ? err.message : err);
        resolve({
          ok: false,
          error: /invalidated|context/i.test(text) ? CONTEXT_MSG : text,
        });
      }
    });
  }

  /** Override page alert/confirm via MAIN world only (no inline script — Manak CSP blocks it). */
  function injectAutoDialogHook() {
    return sendRuntime({ type: "SHRIJA_INSTALL_AUTO_DIALOG" }).then((res) => !!res?.ok);
  }

  function isVisible(el) {
    if (!el || !(el instanceof Element)) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") {
      return false;
    }
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  }

  function buttonLooksOk(el) {
    const text = `${el.textContent || ""} ${el.value || ""} ${el.getAttribute("aria-label") || ""}`
      .trim()
      .toLowerCase()
      .replace(/\s+/g, " ");
    if (!text) return false;
    if (/cancel|close|no\b|nahi|नहीं|रद्द/.test(text)) return false;
    return /^(ok|okay|yes|confirm|save|submit|done|हाँ|हां|ठीक|okey)$/i.test(text) ||
      /\bok\b|\byes\b|\bconfirm\b|\bokay\b/.test(text);
  }

  /** Click OK / Yes on browser-styled or site modals (Bootstrap, jQuery UI, SweetAlert, etc.). */
  function dismissOkDialogs() {
    injectAutoDialogHook();

    const selectors = [
      ".swal2-confirm",
      ".sweet-alert button.confirm",
      ".bootbox .btn-primary",
      ".ui-dialog-buttonset button:first-child",
      ".ui-dialog-buttonpane button.ui-button:first-child",
      ".modal.show .btn-primary",
      ".modal.in .btn-primary",
      ".modal.show .btn-success",
      ".modal.in .btn-success",
      ".jconfirm-buttons .btn-primary",
      ".jconfirm-buttons .btn-success",
      "[role='alertdialog'] button",
      "[role='dialog'] button",
      ".ui-dialog button",
      "div.modal button",
    ];

    for (const sel of selectors) {
      const nodes = document.querySelectorAll(sel);
      for (const btn of nodes) {
        if (!isVisible(btn)) continue;
        if (btn.closest(`#${ROOT_ID}`)) continue;
        if (buttonLooksOk(btn) || /swal2-confirm|btn-primary|btn-success|confirm/i.test(btn.className)) {
          try {
            btn.click();
            return true;
          } catch {
            /* ignore */
          }
        }
      }
    }

    // Generic visible buttons with OK/Yes text (outside our panel)
    const candidates = document.querySelectorAll(
      "button, input[type='button'], input[type='submit'], a.btn, .btn"
    );
    for (const btn of candidates) {
      if (!isVisible(btn) || btn.closest(`#${ROOT_ID}`)) continue;
      // Prefer dialogs / overlays
      const inDialog = btn.closest(
        ".modal, .ui-dialog, .swal2-container, .sweet-alert, .bootbox, .jconfirm, [role='dialog'], [role='alertdialog']"
      );
      if (!inDialog && !buttonLooksOk(btn)) continue;
      if (buttonLooksOk(btn) || (inDialog && /primary|success|confirm/i.test(btn.className || ""))) {
        try {
          btn.click();
          return true;
        } catch {
          /* ignore */
        }
      }
    }
    return false;
  }

  async function flushDialogs(maxMs = DIALOG_WAIT_MS) {
    const start = Date.now();
    let clicked = 0;
    let lastActivity = Date.now();
    while (Date.now() - start < maxMs) {
      if (dismissOkDialogs()) {
        clicked++;
        lastActivity = Date.now();
        await sleep(60);
        continue;
      }
      // No dialog found — stop early once quiet (was waiting full maxMs every row)
      if (Date.now() - lastActivity >= DIALOG_QUIET_MS) break;
      await sleep(40);
    }
    return clicked;
  }

  function startAutoDialogWatcher() {
    autoDialogActive = true;
    void injectAutoDialogHook();
    if (dialogObserver) return;
    dialogObserver = new MutationObserver(() => {
      if (!autoDialogActive) return;
      dismissOkDialogs();
    });
    dialogObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  function stopAutoDialogWatcher() {
    autoDialogActive = false;
    if (dialogObserver) {
      dialogObserver.disconnect();
      dialogObserver = null;
    }
  }

  function decodeParam(value) {
    if (!value) return "";
    try {
      const decoded = atob(value);
      if (/^\d+$/.test(decoded)) return decoded;
    } catch {
      /* not base64 */
    }
    return value;
  }

  function getJobAndRequest() {
    const params = new URLSearchParams(location.search);
    const requestNo = decodeParam(params.get("requestNo") || "");
    const jobNo = decodeParam(params.get("jobNo") || "");

    const jobFromPage =
      textNearLabel(/job\s*card\s*number/i) ||
      textNearLabel(/job\s*card\s*no/i) ||
      "";
    const reqFromPage = textNearLabel(/request\s*no/i) || "";

    return {
      jobNo: jobNo || jobFromPage || "",
      requestNo: requestNo || reqFromPage || "",
    };
  }

  function textNearLabel(labelRe) {
    const nodes = Array.from(document.querySelectorAll("label, td, th, span, div, b, strong"));
    for (const node of nodes) {
      const t = (node.textContent || "").trim();
      if (!labelRe.test(t) || t.length > 80) continue;
      const next = node.nextElementSibling;
      if (next) {
        const v = (next.textContent || "").trim();
        if (v) return v;
      }
      const parent = node.parentElement;
      if (parent) {
        const kids = Array.from(parent.children);
        const idx = kids.indexOf(node);
        if (idx >= 0 && kids[idx + 1]) {
          const v = (kids[idx + 1].textContent || "").trim();
          if (v && !labelRe.test(v)) return v;
        }
      }
    }
    return "";
  }

  function findCaptureTable() {
    const tables = Array.from(document.querySelectorAll("table"));
    for (const table of tables) {
      const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
        (th.textContent || "").trim().toLowerCase()
      );
      const hasAhc = headers.some((h) => h.includes("ahc"));
      const hasWeight = headers.some((h) => h.includes("weight"));
      const hasHuid = headers.some((h) => h.includes("huid"));
      if (hasAhc && (hasWeight || hasHuid)) return table;
    }
    // Fallback: first DataTable with weight inputs
    for (const table of tables) {
      if (table.querySelector('input[placeholder*="Scan weight" i], input[placeholder*="weight" i]')) {
        return table;
      }
    }
    return null;
  }

  function headerIndexMap(table) {
    const headerRow =
      table.querySelector("thead tr") ||
      Array.from(table.querySelectorAll("tr")).find((tr) => tr.querySelector("th"));
    if (!headerRow) return {};
    const map = {};
    Array.from(headerRow.children).forEach((cell, i) => {
      const h = (cell.textContent || "").trim().toLowerCase().replace(/\s+/g, " ");
      if (h.includes("ahc")) map.ahc = i;
      else if (h.includes("weight")) map.weight = i;
      else if (h.includes("huid")) map.huid = i;
      else if (h.includes("save")) map.save = i;
      else if (h.includes("s no") || h === "s.no." || h.includes("serial")) map.sno = i;
    });
    return map;
  }

  function scrapeArticles() {
    const table = findCaptureTable();
    if (!table) return [];

    const map = headerIndexMap(table);
    const bodyRows = Array.from(table.querySelectorAll("tbody tr")).filter((tr) => {
      const text = (tr.textContent || "").trim().toLowerCase();
      if (!text || text.includes("no data available")) return false;
      return tr.querySelectorAll("td").length > 1;
    });

    const { jobNo, requestNo } = getJobAndRequest();
    const articles = [];

    for (const tr of bodyRows) {
      const cells = Array.from(tr.querySelectorAll("td"));
      if (!cells.length) continue;

      let ahcTag = "";
      if (map.ahc != null && cells[map.ahc]) {
        ahcTag = (cells[map.ahc].textContent || "").trim();
      } else {
        // Heuristic: AHC often second column after S No
        ahcTag = (cells[1]?.textContent || cells[0]?.textContent || "").trim();
      }
      if (!ahcTag || !/^\d+$/.test(ahcTag)) {
        // try any numeric-looking short cell that isn't S No
        for (let i = 0; i < Math.min(cells.length, 4); i++) {
          const v = (cells[i].textContent || "").trim();
          if (/^\d{1,6}$/.test(v) && i !== map.sno) {
            ahcTag = v;
            break;
          }
        }
      }
      if (!ahcTag) continue;

      const weightInput =
        cells[map.weight]?.querySelector("input") ||
        tr.querySelector('input[placeholder*="Scan weight" i], input[placeholder*="weight" i], input[type="text"], input[type="number"]');

      const saveBtn =
        cells[map.save]?.querySelector("button, a, input[type='button'], input[type='submit']") ||
        tr.querySelector("button, a.btn, input[type='button'], input[type='submit']");

      articles.push({
        ahcTag,
        tr,
        weightInput,
        saveBtn,
        jobNo,
        requestNo,
      });
    }
    return articles;
  }

  /** Parse DataTables "Showing 1 to 10 of 41 entries" */
  function parseShowingTotal(table) {
    const wrap =
      table?.closest(".dataTables_wrapper") ||
      table?.parentElement?.parentElement ||
      document;
    const info = wrap.querySelector?.(".dataTables_info") || document.querySelector(".dataTables_info");
    const text = (info?.textContent || "").replace(/\s+/g, " ");
    const m = text.match(/of\s+([\d,]+)\s+entries/i) || text.match(/([\d,]+)\s+entries/i);
    if (!m) return null;
    return Number(String(m[1]).replace(/,/g, ""));
  }

  function findLengthSelect(table) {
    const wrap = table?.closest(".dataTables_wrapper");
    const root = wrap || document;
    return (
      root.querySelector(".dataTables_length select") ||
      root.querySelector('select[name$="_length"]') ||
      document.querySelector(".dataTables_length select")
    );
  }

  function expandDataTableViaMain() {
    return sendRuntime({ type: "SHRIJA_EXPAND_DATATABLE" });
  }

  /** Show all DataTable rows (fixes template getting only first page / 10 rows). */
  async function expandCaptureTableAll(opts = {}) {
    const quiet = !!opts.quiet;
    const table = findCaptureTable();
    if (!table) return { ok: false, visible: 0, total: 0 };

    const totalBefore = parseShowingTotal(table);
    if (!quiet) {
      setStatus(
        "info",
        totalBefore ? `Loading all ${totalBefore} entries…` : "Loading all table entries…"
      );
    }

    // 1) Preferred: DataTables API in page MAIN world
    const api = await expandDataTableViaMain();
    await sleep(350);

    let visible = scrapeArticles().length;
    let total = parseShowingTotal(table) || totalBefore || visible;
    if (api?.ok && visible >= (api.rows || total) * 0.9) {
      return { ok: true, visible, total: api.rows || total };
    }

    // 2) DOM: set "Show entries" to All / largest
    const lengthSelect = findLengthSelect(table);
    if (lengthSelect) {
      const values = Array.from(lengthSelect.options).map((o) => o.value);
      if (!values.includes("-1")) {
        const opt = document.createElement("option");
        opt.value = "-1";
        opt.textContent = "All";
        lengthSelect.appendChild(opt);
      }
      const numeric = values
        .map((v) => Number(v))
        .filter((n) => Number.isFinite(n) && n > 0);
      const target =
        values.includes("-1")
          ? "-1"
          : String(Math.max(...numeric, totalBefore || 100, 100));
      if (![...lengthSelect.options].some((o) => o.value === target) && target !== "-1") {
        const opt = document.createElement("option");
        opt.value = target;
        opt.textContent = target;
        lengthSelect.appendChild(opt);
      }
      lengthSelect.value = values.includes("-1") ? "-1" : target;
      lengthSelect.dispatchEvent(new Event("change", { bubbles: true }));
      lengthSelect.dispatchEvent(new Event("input", { bubbles: true }));
      await sleep(450);
    }

    // Wait until row count catches up
    const want = totalBefore || total || 0;
    const waitUntil = Date.now() + 4000;
    while (Date.now() < waitUntil) {
      visible = scrapeArticles().length;
      total = parseShowingTotal(table) || want || visible;
      if (want && visible >= want) break;
      if (!want && visible > 10) break;
      await sleep(120);
    }

    visible = scrapeArticles().length;
    total = parseShowingTotal(table) || totalBefore || visible;
    return { ok: visible > 0, visible, total };
  }

  /** Collect rows across pagination if expand still incomplete. */
  async function scrapeAllArticlesForTemplate() {
    const expanded = await expandCaptureTableAll();
    let articles = scrapeArticles();
    const total = expanded.total || parseShowingTotal(findCaptureTable()) || 0;

    if (!total || articles.length >= total) {
      // de-dupe by AHC
      const map = new Map();
      for (const a of articles) map.set(String(a.ahcTag), a);
      return [...map.values()];
    }

    // Fallback: walk every page
    setStatus("info", `Collecting all pages (${articles.length}/${total})…`);
    const byAhc = new Map();
    const wrap =
      findCaptureTable()?.closest(".dataTables_wrapper") || document;
    const firstBtn = wrap.querySelector(
      ".dataTables_paginate .paginate_button.first:not(.disabled), .paginate_button.first:not(.disabled)"
    );
    if (firstBtn) {
      firstBtn.click();
      await sleep(300);
    }

    for (let page = 0; page < 80; page++) {
      for (const a of scrapeArticles()) {
        byAhc.set(String(a.ahcTag), {
          ahcTag: a.ahcTag,
          jobNo: a.jobNo,
          requestNo: a.requestNo,
        });
      }
      setStatus("info", `Collecting pages… ${byAhc.size}/${total || "?"} rows`);
      if (total && byAhc.size >= total) break;

      const nextBtn = wrap.querySelector(
        ".dataTables_paginate .paginate_button.next:not(.disabled)"
      );
      if (!nextBtn || nextBtn.classList.contains("disabled")) break;
      nextBtn.click();
      await sleep(280);
    }

    return [...byAhc.values()];
  }

  /**
   * Set weight without focusing the field.
   * Focus/click on "Scan weight" opens Chrome serial-port picker and blocks automation.
   */
  function setNativeValue(input, value) {
    const proto = Object.getPrototypeOf(input);
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc?.set) desc.set.call(input, value);
    else input.value = value;

    // Mark dirty for Angular/jQuery/knockout-style bindings without opening serial UI
    input.dispatchEvent(new Event("input", { bubbles: true }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function ensurePanel() {
    let root = document.getElementById(ROOT_ID);
    if (root) return root;

    root = document.createElement("div");
    root.id = ROOT_ID;
    root.innerHTML = `
      <div class="shrija-wc-panel" role="dialog" aria-label="Shrija Weight Capture">
        <div class="shrija-wc-header">
          <div>
            <h1>Shrija Weight Capture</h1>
            <div class="ver">Bulk Scan Weight · v1.3.1 · licensed</div>
          </div>
          <button type="button" class="shrija-wc-close" data-action="close" title="Close">×</button>
        </div>
        <div class="shrija-wc-body">
          <div class="shrija-wc-license">
            <div class="shrija-wc-section-title">License</div>
            <div class="shrija-wc-license-row">
              <input data-role="license-key" placeholder="SHJ-...." autocomplete="off" spellcheck="false" />
              <button type="button" class="shrija-wc-btn shrija-wc-btn-secondary" data-action="activate-license">Activate</button>
            </div>
            <div class="shrija-wc-status" data-role="license-status"></div>
          </div>
          <div class="shrija-wc-app is-locked" data-role="app">
          <div class="shrija-wc-section-title">⚖ Weight Data Upload</div>
          <p class="shrija-wc-hint">
            Excel → Capture ki saari tags ek saath, ya <b>Details ki pehle se saved weights update</b>.
          </p>
          <div class="shrija-wc-drop" data-action="browse" tabindex="0">
            <strong>Click to browse</strong>
            <span>.xlsx or .xls only</span>
          </div>
          <input type="file" accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" hidden data-role="file" />
          <div class="shrija-wc-file-row">
            <span class="shrija-wc-file-name" data-role="file-name">No file selected</span>
            <button type="button" class="shrija-wc-btn shrija-wc-btn-secondary" data-action="template">Download Template</button>
          </div>
          <div class="shrija-wc-preview" data-role="preview" hidden></div>
          <div class="shrija-wc-progress" data-role="progress"><i></i></div>
          <div class="shrija-wc-status" data-role="status"></div>
          <button type="button" class="shrija-wc-btn shrija-wc-btn-primary" data-action="process" disabled>
            Process &amp; Save Weights
          </button>
          <hr class="shrija-wc-divider" />
          <div class="shrija-wc-section-title">🗑 Delete Filled Weights</div>
          <p class="shrija-wc-hint">
            Capture clear / Details delete. Portal pe Delete na ho aur Capture empty ho to
            pehle kisi job me <b>ek Save</b> dabao (API seekhne), phir Delete try karo.
          </p>
          <div class="shrija-wc-btn-row">
            <button type="button" class="shrija-wc-btn shrija-wc-btn-secondary" data-action="clear-capture">
              Clear Capture Fields
            </button>
            <button type="button" class="shrija-wc-btn shrija-wc-btn-danger" data-action="delete-saved">
              Delete Saved (Details)
            </button>
          </div>
          </div>
        </div>
        <div class="shrija-wc-footer">Shrija Weight Capture · Manak Online Weighing Desk</div>
      </div>
    `;
    document.documentElement.appendChild(root);
    wirePanel(root);
    void refreshLicense();
    return root;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (value) => {
          void chrome.runtime.lastError;
          resolve(value || {});
        });
      } catch {
        resolve({});
      }
    });
  }

  function storageSet(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, () => {
          void chrome.runtime.lastError;
          resolve();
        });
      } catch {
        resolve();
      }
    });
  }

  async function getInstallId() {
    const cur = await storageGet(["shrijaInstallId"]);
    if (cur.shrijaInstallId) return cur.shrijaInstallId;
    const id = crypto.randomUUID();
    await storageSet({ shrijaInstallId: id });
    return id;
  }

  function syncProcessButton() {
    const processBtn = document.querySelector(`#${ROOT_ID} [data-action="process"]`);
    if (processBtn) processBtn.disabled = !licenseOk || pendingRows.length === 0;
  }

  function showLicense(state) {
    licenseOk = !!state.ok;
    const box = document.querySelector(`#${ROOT_ID} [data-role="license-status"]`);
    const app = document.querySelector(`#${ROOT_ID} [data-role="app"]`);
    if (app) app.classList.toggle("is-locked", !licenseOk);
    if (box) {
      box.className = `shrija-wc-status show ${licenseOk ? "ok" : "err"}`;
      if (licenseOk) {
        const till = state.expiresAt ? new Date(state.expiresAt).toLocaleDateString("en-IN") : "";
        box.textContent = `Active${state.customer ? " · " + state.customer : ""}${till ? " · " + till + " tak" : ""}`;
      } else {
        box.textContent = state.message || "License key daalo. Bina license ke weight fill band hai.";
      }
    }
    syncProcessButton();
  }

  async function refreshLicense() {
    const stored = await storageGet(["shrijaLicenseKey"]);
    const input = document.querySelector(`#${ROOT_ID} [data-role="license-key"]`);
    const key = String(stored.shrijaLicenseKey || "").trim();
    if (input && key && !input.value) input.value = key;
    if (!key) {
      showLicense({ ok: false, message: "License key daalo. Bina license ke weight fill band hai." });
      return false;
    }
    const installId = await getInstallId();
    const res = await sendRuntime({
      type: "SHRIJA_LICENSE_CHECK",
      key,
      installId,
      label: navigator.platform || "PC",
    });
    showLicense(res && res.ok ? res : { ok: false, message: res?.message || "License server nahi mil raha." });
    return !!res?.ok;
  }

  async function activateLicense() {
    const input = document.querySelector(`#${ROOT_ID} [data-role="license-key"]`);
    const key = String(input?.value || "").trim().toUpperCase();
    if (!key) {
      showLicense({ ok: false, message: "License key daalo." });
      return;
    }
    await storageSet({ shrijaLicenseKey: key });
    const ok = await refreshLicense();
    if (!ok) setStatus("err", document.querySelector(`#${ROOT_ID} [data-role="license-status"]`)?.textContent || "License fail.");
  }

  async function requireLicense() {
    const ok = await refreshLicense();
    if (!ok) {
      const message =
        document.querySelector(`#${ROOT_ID} [data-role="license-status"]`)?.textContent ||
        "License active nahi hai.";
      setStatus("err", message);
    }
    return ok;
  }

  function wirePanel(root) {
    const fileInput = root.querySelector('[data-role="file"]');
    const drop = root.querySelector('[data-action="browse"]');

    root.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-action]");
      if (!btn) return;
      const action = btn.getAttribute("data-action");
      if (action === "close") {
        root.style.display = "none";
      } else if (action === "activate-license") {
        void activateLicense();
      } else if (action === "browse") {
        fileInput.click();
      } else if (action === "template") {
        void downloadTemplate();
      } else if (action === "process") {
        void processAndSave();
      } else if (action === "clear-capture") {
        void clearCaptureFields();
      } else if (action === "delete-saved") {
        void deleteSavedDetails();
      }
    });

    drop.addEventListener("dragover", (e) => {
      e.preventDefault();
      drop.classList.add("dragover");
    });
    drop.addEventListener("dragleave", () => drop.classList.remove("dragover"));
    drop.addEventListener("drop", (e) => {
      e.preventDefault();
      drop.classList.remove("dragover");
      const file = e.dataTransfer?.files?.[0];
      if (file) handleFile(file);
    });

    fileInput.addEventListener("change", () => {
      const file = fileInput.files?.[0];
      if (file) handleFile(file);
    });

    root.querySelector('[data-role="license-key"]')?.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        void activateLicense();
      }
    });
  }

  function setStatus(type, message) {
    const el = document.querySelector(`#${ROOT_ID} [data-role="status"]`);
    if (!el) return;
    el.className = `shrija-wc-status show ${type}`;
    el.textContent = message;
  }

  function setProgress(done, total) {
    const bar = document.querySelector(`#${ROOT_ID} [data-role="progress"]`);
    if (!bar) return;
    if (!total) {
      bar.classList.remove("show");
      return;
    }
    bar.classList.add("show");
    const pct = Math.round((done / total) * 100);
    bar.querySelector("i").style.width = `${pct}%`;
  }

  async function downloadTemplate() {
    if (!(await requireLicense())) return;
    if (typeof XLSX === "undefined") {
      setStatus("err", "Excel library not loaded. Reload the page and try again.");
      return;
    }

    setStatus("info", "Collecting all table entries for template…");
    let articles = await scrapeAllArticlesForTemplate();
    const { jobNo, requestNo } = getJobAndRequest();
    let fromDetails = false;

    if (!articles.length) {
      await expandDetailsTableAll();
      const details = scrapeDetailsRows();
      articles = details.map((d) => ({
        ahcTag: d.ahcTag,
        jobNo,
        requestNo,
      }));
      fromDetails = articles.length > 0;
    }

    if (!articles.length) {
      setStatus("err", "Na Capture me pending tags hain, na Details me saved tags.");
      return;
    }

    const rows = articles.map((a) => ({
      AHC_Tag: a.ahcTag,
      Weight: "",
      Job_No: a.jobNo || jobNo,
      Request_No: a.requestNo || requestNo,
    }));

    const sheet = XLSX.utils.json_to_sheet(rows, {
      header: ["AHC_Tag", "Weight", "Job_No", "Request_No"],
    });
    sheet["!cols"] = [{ wch: 12 }, { wch: 12 }, { wch: 14 }, { wch: 14 }];
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, "Template");
    const name = `Weight_Template_${jobNo || "job"}.xlsx`;
    XLSX.writeFile(book, name);
    setStatus(
      "ok",
      fromDetails
        ? `Template ${articles.length} Details tags se bani. Capture khaali hai — nayi weight se pehle Delete Saved karo, tab Scan fields wapas aayengi.`
        : `Template downloaded (${articles.length} rows). Fill Weight column, then upload.`
    );
  }

  function normalizeHeader(h) {
    return String(h || "")
      .trim()
      .toLowerCase()
      .replace(/\s+/g, "_")
      .replace(/[^a-z0-9_]/g, "");
  }

  function handleFile(file) {
    const name = file.name || "";
    if (!/\.xlsx?$/i.test(name)) {
      setStatus("err", "Only .xlsx or .xls files are allowed.");
      return;
    }
    selectedFileName = name;
    const nameEl = document.querySelector(`#${ROOT_ID} [data-role="file-name"]`);
    if (nameEl) nameEl.textContent = name;

    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        if (typeof XLSX === "undefined") throw new Error("XLSX missing");
        const data = new Uint8Array(ev.target.result);
        const book = XLSX.read(data, { type: "array" });
        const sheet = book.Sheets[book.SheetNames[0]];
        const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        pendingRows = parseWeightRows(json);
        renderPreview(pendingRows);
        const processBtn = document.querySelector(`#${ROOT_ID} [data-action="process"]`);
        syncProcessButton();
        if (!pendingRows.length) {
          setStatus("err", "No valid rows with AHC_Tag + Weight found in Excel.");
        } else {
          setStatus("info", `${pendingRows.length} weight row(s) ready. Click Process & Save Weights.`);
        }
      } catch (err) {
        setStatus("err", `Failed to read Excel: ${err.message || err}`);
        pendingRows = [];
      }
    };
    reader.onerror = () => setStatus("err", "Could not read the selected file.");
    reader.readAsArrayBuffer(file);
  }

  function parseWeightRows(json) {
    const out = [];
    for (const row of json) {
      const keyed = {};
      for (const [k, v] of Object.entries(row)) {
        keyed[normalizeHeader(k)] = v;
      }
      const ahcTag = String(
        keyed.ahc_tag ?? keyed.ahctag ?? keyed.ahc ?? keyed.tag ?? ""
      ).trim();
      const weightRaw = keyed.weight ?? keyed.weight_gms ?? keyed.wt;
      const weightStr =
        weightRaw === undefined || weightRaw === null
          ? ""
          : String(weightRaw).replace(/,/g, "").trim();
      const weight = Number(weightStr);
      const jobNo = String(keyed.job_no ?? keyed.jobno ?? keyed.job_card_number ?? "").trim();
      const requestNo = String(keyed.request_no ?? keyed.requestno ?? "").trim();

      // 0 is valid; empty / non-numeric / negative are not
      if (!ahcTag || weightStr === "" || !Number.isFinite(weight) || weight < 0) continue;
      out.push({ ahcTag, weight, jobNo, requestNo });
    }
    return out;
  }

  function renderPreview(rows) {
    const box = document.querySelector(`#${ROOT_ID} [data-role="preview"]`);
    if (!box) return;
    if (!rows.length) {
      box.hidden = true;
      box.innerHTML = "";
      return;
    }
    box.hidden = false;
    const head = `<tr><th>AHC_Tag</th><th>Weight</th><th>Job_No</th><th>Request_No</th></tr>`;
    const body = rows
      .map(
        (r) =>
          `<tr><td>${escapeHtml(r.ahcTag)}</td><td>${escapeHtml(String(r.weight))}</td><td>${escapeHtml(r.jobNo)}</td><td>${escapeHtml(r.requestNo)}</td></tr>`
      )
      .join("");
    box.innerHTML = `<table><thead>${head}</thead><tbody>${body}</tbody></table>`;
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /**
   * Fill EVERY visible Scan weight field in one synchronous pass.
   * Values first (so UI shows all together), then input/change events.
   */
  function fillAllWeights(weightByAhc) {
    const live = scrapeArticles();
    /** @type {HTMLInputElement[]} */
    const touched = [];
    for (const article of live) {
      const weight = weightByAhc.get(String(article.ahcTag));
      if (weight == null || !article.weightInput) continue;
      const input = article.weightInput;
      const proto = Object.getPrototypeOf(input);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc?.set) desc.set.call(input, String(weight));
      else input.value = String(weight);
      touched.push(input);
    }
    for (const input of touched) {
      input.dispatchEvent(new Event("input", { bubbles: true }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
    }
    return touched.length;
  }

  /** Article Weight Details table (saved rows — not the Capture table). */
  function findDetailsTable() {
    // 1) Prefer table under the "Article Weight Details" heading
    const labelNodes = Array.from(
      document.querySelectorAll("h1,h2,h3,h4,h5,h6,legend,label,b,strong,span,div,td,th,p")
    );
    for (const el of labelNodes) {
      const t = (el.textContent || "").replace(/\s+/g, " ").trim();
      if (!/^article\s*weight\s*details$/i.test(t) && !/^article\s*weight\s*details\b/i.test(t)) {
        continue;
      }
      if (t.length > 80) continue;
      let scope = el.parentElement;
      for (let i = 0; i < 6 && scope; i++) {
        const table = scope.querySelector("table");
        if (table && isDetailsLikeTable(table)) return table;
        scope = scope.parentElement;
      }
      let sib = el.nextElementSibling;
      for (let i = 0; i < 8 && sib; i++) {
        const table = sib.matches?.("table") ? sib : sib.querySelector?.("table");
        if (table && isDetailsLikeTable(table)) return table;
        sib = sib.nextElementSibling;
      }
    }

    // 2) Score candidates: must have real data rows, prefer no Save column
    let best = null;
    let bestScore = -1;
    for (const table of document.querySelectorAll("table")) {
      if (!isDetailsLikeTable(table)) continue;
      const score = scoreDetailsTable(table);
      if (score > bestScore) {
        bestScore = score;
        best = table;
      }
    }
    return bestScore > 0 ? best : null;
  }

  function isDetailsLikeTable(table) {
    if (!table) return false;
    // Capture table while editable — never treat as Details
    if (
      table.querySelector(
        'input[placeholder*="Scan weight" i], input[placeholder*="weight" i]'
      )
    ) {
      return false;
    }
    const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
      (th.textContent || "").trim().toLowerCase()
    );
    if (!headers.length) return false;
    if (!headers.some((h) => h.includes("ahc"))) return false;
    if (!headers.some((h) => h.includes("weight"))) return false;
    // Capture table has Save column even when empty ("No data available")
    if (headers.some((h) => h === "save" || h.includes("save"))) return false;
    return true;
  }

  function scoreDetailsTable(table) {
    const bodyRows = Array.from(table.querySelectorAll("tbody tr")).filter((tr) => {
      const text = (tr.textContent || "").trim().toLowerCase();
      return text && !text.includes("no data available") && tr.querySelectorAll("td").length > 1;
    });
    if (!bodyRows.length) return 0;
    let score = bodyRows.length;
    const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
      (th.textContent || "").trim().toLowerCase()
    );
    if (headers.some((h) => h.includes("huid"))) score += 2;
    // Near Details heading
    const wrap = table.closest(".dataTables_wrapper") || table.parentElement;
    const prev = `${wrap?.previousElementSibling?.textContent || ""}`;
    if (/article\s*weight\s*details/i.test(prev)) score += 10;
    return score;
  }

  function scrapeDetailsRows() {
    const table = findDetailsTable();
    if (!table) return [];
    const map = headerIndexMap(table);
    const bodyRows = Array.from(table.querySelectorAll("tbody tr")).filter((tr) => {
      const text = (tr.textContent || "").trim().toLowerCase();
      return text && !text.includes("no data available") && tr.querySelectorAll("td").length > 1;
    });
    const rows = [];
    for (const tr of bodyRows) {
      const cells = Array.from(tr.querySelectorAll("td"));
      let ahcTag = "";
      if (map.ahc != null && cells[map.ahc]) {
        ahcTag = (cells[map.ahc].textContent || "").trim();
      } else {
        ahcTag = (cells[1]?.textContent || cells[0]?.textContent || "").trim();
      }
      if (!ahcTag || !/^\d+$/.test(ahcTag)) {
        for (let i = 0; i < Math.min(cells.length, 4); i++) {
          const v = (cells[i].textContent || "").trim();
          if (/^\d{1,6}$/.test(v) && i !== map.sno) {
            ahcTag = v;
            break;
          }
        }
      }
      if (!ahcTag) continue;
      const weightText =
        (map.weight != null && cells[map.weight]
          ? cells[map.weight].textContent
          : cells[cells.length - 1]?.textContent) || "";
      const huid =
        map.huid != null && cells[map.huid]
          ? (cells[map.huid].textContent || "").trim()
          : "";
      rows.push({
        ahcTag,
        huid,
        tr,
        weight: String(weightText).replace(/,/g, "").trim(),
        deleteBtn: findRowDeleteControl(tr),
      });
    }
    return rows;
  }

  function looksLikeDeleteControl(el) {
    if (!el || !(el instanceof Element)) return false;
    if (el.closest(`#${ROOT_ID}`)) return false;
    const text = `${el.textContent || ""} ${el.value || ""} ${el.title || ""} ${el.getAttribute("aria-label") || ""} ${el.getAttribute("onclick") || ""} ${el.className || ""} ${el.getAttribute("href") || ""}`
      .trim()
      .toLowerCase();
    if (/cancel|close|print|export|excel|pdf|save|edit|update|search/i.test(text) && !/delete|remove|trash|हटा/i.test(text)) {
      return false;
    }
    return (
      /delete|remove|trash|हटा|मिटा|clear/i.test(text) ||
      /fa-trash|glyphicon-trash|glyphicon-remove|btn-danger|icon-trash|icon-delete/i.test(text)
    );
  }

  function findRowDeleteControl(tr) {
    const candidates = tr.querySelectorAll(
      "a, button, input[type='button'], input[type='submit'], img, i, span[onclick], [onclick]"
    );
    for (const el of candidates) {
      if (!looksLikeDeleteControl(el)) continue;
      // Prefer clickable parent if icon
      if (el.tagName === "I" || el.tagName === "IMG" || el.tagName === "SPAN") {
        const clickable = el.closest("a, button, [onclick]");
        if (clickable) return clickable;
      }
      return el;
    }
    // Last cell often holds action icons even without text
    const last = tr.querySelector("td:last-child");
    if (last) {
      const btn =
        last.querySelector("a, button, [onclick], img, i.fa, i.glyphicon") || null;
      if (btn && !/save|edit|print/i.test(btn.textContent || btn.className || "")) {
        if (
          /trash|delete|remove|danger|times|remove/i.test(
            `${btn.className} ${btn.getAttribute("onclick") || ""} ${btn.title || ""}`
          )
        ) {
          return btn.closest("a, button, [onclick]") || btn;
        }
      }
    }
    return null;
  }

  async function expandDetailsTableAll() {
    const table = findDetailsTable();
    if (!table) return { ok: false, visible: 0 };
    const wrap = table.closest(".dataTables_wrapper");
    const lengthSelect =
      wrap?.querySelector(".dataTables_length select") ||
      wrap?.querySelector('select[name$="_length"]');
    if (lengthSelect) {
      if (![...lengthSelect.options].some((o) => o.value === "-1")) {
        const opt = document.createElement("option");
        opt.value = "-1";
        opt.textContent = "All";
        lengthSelect.appendChild(opt);
      }
      lengthSelect.value = "-1";
      lengthSelect.dispatchEvent(new Event("change", { bubbles: true }));
      await sleep(350);
    }
    // MAIN-world DataTables expand for this table too
    await expandDataTableViaMain();
    await sleep(200);
    return { ok: true, visible: scrapeDetailsRows().length };
  }

  /** Clear unsaved values in Articles Weight Capture Scan weight inputs. */
  async function clearCaptureFields(opts = {}) {
    const quiet = !!opts.quiet;
    if (!quiet && !(await requireLicense())) return 0;
    await expandCaptureTableAll({ quiet: true });
    const articles = scrapeArticles();
    let cleared = 0;
    for (const a of articles) {
      if (!a.weightInput) continue;
      const v = String(a.weightInput.value || "").trim();
      if (!v) continue;
      const proto = Object.getPrototypeOf(a.weightInput);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc?.set) desc.set.call(a.weightInput, "");
      else a.weightInput.value = "";
      a.weightInput.dispatchEvent(new Event("input", { bubbles: true }));
      a.weightInput.dispatchEvent(new Event("change", { bubbles: true }));
      cleared++;
    }
    if (!quiet) {
      if (cleared) {
        setStatus("ok", `Cleared ${cleared} Capture Scan weight field(s).`);
      } else {
        setStatus("info", "Capture fields already empty — kuch clear karne ko nahi mila.");
      }
    }
    return cleared;
  }

  function deleteViaApi(filterAhcs) {
    return new Promise((resolve) => {
      const root = document.documentElement;
      const obs = new MutationObserver(() => {
        const msg = root.getAttribute("data-shrija-del-progress");
        if (msg) setStatus("info", msg);
      });
      obs.observe(root, { attributes: true, attributeFilter: ["data-shrija-del-progress"] });
      sendRuntime({ type: "SHRIJA_DELETE_SAVED", filterAhcs: filterAhcs || null }).then((res) => {
        obs.disconnect();
        resolve(res || { ok: false });
      });
    });
  }

  /** Delete saved rows from Article Weight Details (UI Delete, else API reset). */
  async function deleteSavedDetails() {
    if (!(await requireLicense())) return;
    startAutoDialogWatcher();
    await injectAutoDialogHook();

    const deleteBtn = document.querySelector(`#${ROOT_ID} [data-action="delete-saved"]`);
    const clearBtn = document.querySelector(`#${ROOT_ID} [data-action="clear-capture"]`);
    if (deleteBtn) deleteBtn.disabled = true;
    if (clearBtn) clearBtn.disabled = true;

    let deleted = 0;
    let rounds = 0;
    let sawDeleteControl = false;

    try {
      setStatus("info", "Loading all saved Details rows…");
      await expandDetailsTableAll();

      let initialRows = scrapeDetailsRows();
      if (!initialRows.length) {
        // One more pass after short wait (DataTables late draw)
        await sleep(300);
        await expandDetailsTableAll();
        initialRows = scrapeDetailsRows();
      }

      if (!initialRows.length) {
        setStatus(
          "err",
          "Article Weight Details table nahi mili / rows read nahi hui. Page refresh karke dubara try karo."
        );
        return;
      }

      setStatus("info", `Details me ${initialRows.length} saved row(s) mili. Deleting…`);

      const filterAhc =
        pendingRows.length > 0
          ? new Set(pendingRows.map((r) => String(r.ahcTag)))
          : null;

      if (filterAhc) {
        setStatus("info", `Excel filter ON — sirf ${filterAhc.size} AHC tag(s) delete hongi…`);
      }

      let emptyStreak = 0;
      while (emptyStreak < 3 && rounds < 80) {
        rounds++;
        await expandDetailsTableAll();
        let rows = scrapeDetailsRows();
        if (filterAhc) {
          rows = rows.filter((r) => filterAhc.has(String(r.ahcTag)));
        }

        const withDelete = rows.filter((r) => r.deleteBtn);
        if (withDelete.length) sawDeleteControl = true;

        if (!withDelete.length) {
          const wrap = findDetailsTable()?.closest(".dataTables_wrapper");
          const next = wrap?.querySelector(
            ".dataTables_paginate .paginate_button.next:not(.disabled)"
          );
          if (next) {
            next.click();
            await sleep(300);
            continue;
          }
          emptyStreak++;
          await sleep(150);
          continue;
        }
        emptyStreak = 0;

        const target = withDelete[0];
        const beforeCount = scrapeDetailsRows().length;
        setStatus("info", `Deleting saved AHC ${target.ahcTag}… (${deleted} done)`);
        try {
          target.deleteBtn.click();
        } catch {
          /* ignore */
        }
        await flushDialogs(Math.max(DIALOG_WAIT_MS, 700));
        dismissOkDialogs();
        await sleep(320);

        const afterCount = scrapeDetailsRows().length;
        const still = scrapeDetailsRows().some(
          (r) => String(r.ahcTag) === String(target.ahcTag)
        );
        if (!still || afterCount < beforeCount) {
          deleted++;
          setProgress(deleted, deleted + rows.length);
        } else {
          await flushDialogs(800);
          dismissOkDialogs();
          await sleep(250);
          const still2 = scrapeDetailsRows().some(
            (r) => String(r.ahcTag) === String(target.ahcTag)
          );
          if (!still2) deleted++;
          else emptyStreak++;
        }
      }

      let left = scrapeDetailsRows().length;

      // No UI Delete on this portal — try Manak weight delete/reset API
      if (left && !sawDeleteControl) {
        setStatus(
          "info",
          `UI Delete nahi mila. API se ${left} saved row(s) delete try… (thoda time lagega)`
        );
        const apiRes = await deleteViaApi(filterAhc ? [...filterAhc] : null);
        if (apiRes?.deleted) deleted += apiRes.deleted;
        await sleep(400);
        await expandDetailsTableAll();
        left = scrapeDetailsRows().length;

        if (apiRes?.deleted && !left) {
          const cleared = await clearCaptureFields({ quiet: true });
          setStatus(
            "ok",
            `API se ${apiRes.deleted} saved weight(s) delete ho gayi.${cleared ? ` Cleared ${cleared} Capture field(s).` : ""}`
          );
          return;
        }
        if (apiRes?.deleted) {
          setStatus(
            "ok",
            `API se ${apiRes.deleted} delete. Details left: ${left}.${apiRes.failed?.length ? ` Fail: ${apiRes.failed.join(", ")}` : ""}`
          );
          return;
        }
        setStatus(
          "err",
          apiRes?.hint ||
            `API delete fail (urls: ${apiRes?.urlsTried || 0}). Capture abhi empty hai — is job pe Save se API nahi seekh sakte. Left: ${left}.`
        );
        return;
      }

      const cleared = await clearCaptureFields({ quiet: true });
      left = scrapeDetailsRows().length;

      if (deleted) {
        setStatus(
          "ok",
          `Deleted ${deleted} saved weight(s). Details left: ${left}.${cleared ? ` Cleared ${cleared} Capture field(s).` : ""}`
        );
      } else if (left) {
        setStatus(
          "err",
          `Delete try hua lekin ${left} row(s) Details me reh gayi. Confirm dialog check karein ya manually delete karein.`
        );
      } else {
        setStatus(
          "ok",
          `Details empty.${cleared ? ` Cleared ${cleared} Capture field(s).` : ""}`
        );
      }
    } finally {
      stopAutoDialogWatcher();
      setProgress(0, 0);
      if (deleteBtn) deleteBtn.disabled = false;
      if (clearBtn) clearBtn.disabled = false;
    }
  }

  /** Click every remaining row's Save in one burst (no per-row wait). */
  function clickAllSaveButtons(remaining) {
    const live = scrapeArticles().filter(
      (a) => remaining.has(String(a.ahcTag)) && (a.saveBtn || a.weightInput)
    );
    let clicked = 0;
    for (const a of live) {
      if (a.saveBtn) {
        a.saveBtn.click();
        clicked++;
      } else if (a.weightInput) {
        a.weightInput.dispatchEvent(
          new KeyboardEvent("keydown", { bubbles: true, key: "Enter", code: "Enter" })
        );
        clicked++;
      }
    }
    return clicked;
  }

  function captureWrapper() {
    return findCaptureTable()?.closest(".dataTables_wrapper") || document;
  }

  function goToFirstCapturePage() {
    const firstBtn = captureWrapper().querySelector(
      ".dataTables_paginate .paginate_button.first:not(.disabled)"
    );
    if (firstBtn) {
      firstBtn.click();
      return true;
    }
    return false;
  }

  function goToNextCapturePage() {
    const nextBtn = captureWrapper().querySelector(
      ".dataTables_paginate .paginate_button.next:not(.disabled)"
    );
    if (nextBtn) {
      nextBtn.click();
      return true;
    }
    return false;
  }

  /** Bring as many remaining rows as possible into the DOM. */
  async function revealRemainingArticles(remaining) {
    await expandCaptureTableAll({ quiet: true });
    let live = scrapeArticles().filter(
      (a) => remaining.has(String(a.ahcTag)) && a.weightInput
    );
    if (live.length) return live;

    if (goToFirstCapturePage()) await sleep(250);
    for (let page = 0; page < 100; page++) {
      live = scrapeArticles().filter(
        (a) => remaining.has(String(a.ahcTag)) && a.weightInput
      );
      if (live.length) return live;
      if (!goToNextCapturePage()) break;
      await sleep(250);
    }
    return [];
  }

  /** After a burst save, drop AHCs that left the capture table. */
  async function settleBurstSaves(remaining, total, okStart) {
    await flushDialogs(DIALOG_WAIT_MS);
    dismissOkDialogs();

    const waitUntil = Date.now() + Math.min(1200 + remaining.size * 40, 5000);
    let ok = okStart;
    while (Date.now() < waitUntil && remaining.size) {
      await expandCaptureTableAll({ quiet: true });
      const still = new Set(
        scrapeArticles()
          .filter((a) => a.weightInput)
          .map((a) => String(a.ahcTag))
      );
      let progressed = false;
      for (const ahc of [...remaining]) {
        if (!still.has(ahc)) {
          remaining.delete(ahc);
          ok++;
          progressed = true;
        }
      }
      if (progressed) {
        setProgress(ok, total);
        setStatus("info", `Saved ${ok}/${total}… (${remaining.size} left)`);
      }
      if (!remaining.size) break;
      await sleep(80);
    }
    return ok;
  }

  function fillBypassSave(rows) {
    return sendRuntime({ type: "SHRIJA_FILL_BYPASS_SAVE", rows });
  }

  function updateSavedWeights(rows) {
    return new Promise((resolve) => {
      const root = document.documentElement;
      const obs = new MutationObserver(() => {
        const msg = root.getAttribute("data-shrija-upd-progress");
        if (msg) setStatus("info", msg);
      });
      obs.observe(root, { attributes: true, attributeFilter: ["data-shrija-upd-progress"] });
      sendRuntime({ type: "SHRIJA_UPDATE_SAVED", rows }).then((res) => {
        obs.disconnect();
        resolve(res || { ok: false });
      });
    });
  }

  async function processAndSave() {
    if (!(await requireLicense())) return;
    if (!pendingRows.length) {
      setStatus("err", "Upload an Excel file with weights first.");
      return;
    }

    const processBtn = document.querySelector(`#${ROOT_ID} [data-action="process"]`);
    if (processBtn) processBtn.disabled = true;

    if (!runtimeAlive()) {
      if (processBtn) processBtn.disabled = false;
      setStatus("err", CONTEXT_MSG);
      return;
    }

    const total = pendingRows.length;
    startAutoDialogWatcher();
    await injectAutoDialogHook();
    setProgress(0, total);

    try {
      await expandCaptureTableAll({ quiet: true });
      const captureFields = scrapeArticles().filter((a) => a.weightInput);
      if (!captureFields.length) {
        await expandDetailsTableAll();
        const details = scrapeDetailsRows();
        if (!details.length) {
          setStatus("err", "Capture khaali hai aur Details me bhi koi saved weight nahi.");
          return;
        }
        setStatus("info", `Capture khaali hai. ${details.length} saved weights Excel se update ho rahi hain…`);
        const upd = await updateSavedWeights(
          pendingRows.map((r) => ({ ahcTag: String(r.ahcTag), weight: r.weight }))
        );
        const updated = Number(upd?.updated || 0);
        const unchanged = Number(upd?.unchanged || 0);
        const failed = Array.isArray(upd?.failed) ? upd.failed : [];
        const missing = Array.isArray(upd?.missing) ? upd.missing : [];
        setProgress(updated, total);
        if (updated && !failed.length) {
          setStatus(
            "ok",
            `Saved weights update ho gayi: ${updated}.${unchanged ? ` ${unchanged} pehle se same.` : ""}${missing.length ? ` Excel me extra AHC: ${missing.join(", ")}` : ""}`
          );
        } else if (updated) {
          setStatus("err", `Update ${updated}. Fail AHC: ${failed.join(", ")}.${upd?.error ? ` ${upd.error}` : ""}`);
        } else if (!failed.length && unchanged) {
          setStatus(
            "ok",
            upd?.error || `Details me ${unchanged} weight pehle se Excel jaisi hain. Badalne ke liye Excel me nayi weight likho.`
          );
        } else {
          setStatus("err", upd?.error || "Saved weight update nahi hui.");
        }
        return;
      }

      setStatus("info", `Saari ${total} tag IDs ek saath fill ho rahi hain — Save refresh bypass…`);
      const res = await fillBypassSave(
        pendingRows.map((r) => ({ ahcTag: String(r.ahcTag), weight: r.weight }))
      );
      const filled = Number(res?.filled || 0);
      const fired = Number(res?.fired || 0);
      const saved = Number(res?.saved || 0);
      const left = Array.isArray(res?.left) ? res.left : [];
      setProgress(saved || fired || filled, total);

      if (!filled) {
        setStatus("err", res?.error || "Koi Scan weight field fill nahi hui.");
        return;
      }
      if (saved && !left.length) {
        setStatus("ok", `Done. ${filled} tag ek saath fill, ${saved} save (refresh bypass).`);
      } else if (fired) {
        setStatus(
          "ok",
          `Filled ${filled} tag ek saath. Save bypass se ${fired} bheji.${saved ? ` Confirm ${saved}.` : ""}${left.length ? ` Left: ${left.join(", ")}` : ""}`
        );
      } else {
        setStatus("err", res?.error || `Fields fill hui (${filled}) lekin Save trigger nahi hua.`);
      }
    } finally {
      stopAutoDialogWatcher();
      await flushDialogs(400);
      if (processBtn) processBtn.disabled = false;
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "SHRIJA_TOGGLE_PANEL") {
      const root = ensurePanel();
      const hidden = root.style.display === "none";
      root.style.display = hidden ? "" : "none";
    }
  });

  // Auto-show panel on Weighing Desk so user sees it immediately
  if (/UID_WeighingForm/i.test(location.pathname)) {
    const boot = () => {
      void injectAutoDialogHook();
      ensurePanel();
    };
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", boot, { once: true });
    } else {
      boot();
    }
  }
})();
