/**
 * MAIN-world: update weights already stored in Article Weight Details.
 * Uses only the save call that already exists in the Weighing Desk page,
 * then checks the Details table to confirm the new number.
 */
(() => {
  if (window.__SHRIJA_UPDATE_API__ && window.__SHRIJA_UPDATE_API__.__v >= 1) return;

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function progress(msg) {
    try {
      document.documentElement.setAttribute("data-shrija-upd-progress", String(msg || ""));
    } catch {
      /* ignore */
    }
  }

  function decodeParam(value) {
    if (!value) return "";
    try {
      const decoded = atob(value);
      if (/^\d+$/.test(decoded)) return decoded;
    } catch {
      /* ignore */
    }
    return value;
  }

  function jobRequest() {
    const params = new URLSearchParams(location.search);
    return {
      jobNo: decodeParam(params.get("jobNo") || ""),
      requestNo: decodeParam(params.get("requestNo") || ""),
    };
  }

  function num(value) {
    const n = Number(String(value == null ? "" : value).replace(/,/g, "").trim());
    return Number.isFinite(n) ? n : null;
  }

  function same(a, b) {
    const na = num(a);
    const nb = num(b);
    return na != null && nb != null && Math.abs(na - nb) < 0.001;
  }

  function headersOf(table) {
    return Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
      String(th.textContent || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ")
    );
  }

  function findDetailsTable() {
    const tables = Array.from(document.querySelectorAll("table"));
    let best = null;
    let bestScore = -1;
    for (const table of tables) {
      if (table.querySelector('input[placeholder*="weight" i]')) continue;
      const headers = headersOf(table);
      if (!headers.some((h) => h.includes("ahc"))) continue;
      if (!headers.some((h) => h.includes("weight"))) continue;
      if (headers.some((h) => h === "save" || h.includes("save"))) continue;
      const rows = table.querySelectorAll("tbody tr").length;
      let score = rows;
      const prev = table.closest(".dataTables_wrapper")?.previousElementSibling?.textContent || "";
      if (/article\s*weight\s*details/i.test(prev)) score += 20;
      if (score > bestScore) {
        bestScore = score;
        best = table;
      }
    }
    return best;
  }

  function headerIndex(table) {
    const map = {};
    const row =
      table.querySelector("thead tr") ||
      Array.from(table.querySelectorAll("tr")).find((tr) => tr.querySelector("th"));
    if (!row) return map;
    Array.from(row.children).forEach((cell, i) => {
      const h = String(cell.textContent || "")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ");
      if (h.includes("ahc")) map.ahc = i;
      else if (h.includes("weight")) map.weight = i;
      else if (h.includes("huid")) map.huid = i;
    });
    return map;
  }

  function expand(table) {
    const $ = window.jQuery;
    try {
      if ($ && $.fn && $.fn.dataTable && $.fn.dataTable.isDataTable(table)) {
        const dt = $(table).DataTable();
        try {
          dt.settings()[0]._iDisplayLength = -1;
        } catch {
          /* ignore */
        }
        dt.page.len(-1).draw(false);
      }
    } catch {
      /* ignore */
    }
  }

  function readDetails() {
    const table = findDetailsTable();
    if (!table) return [];
    expand(table);
    const map = headerIndex(table);
    const $ = window.jQuery;
    let dt = null;
    try {
      if ($ && $.fn && $.fn.dataTable && $.fn.dataTable.isDataTable(table)) dt = $(table).DataTable();
    } catch {
      dt = null;
    }
    const out = [];
    table.querySelectorAll("tbody tr").forEach((tr) => {
      const text = String(tr.textContent || "").toLowerCase();
      if (!text || text.includes("no data")) return;
      const cells = tr.querySelectorAll("td");
      if (cells.length < 2 || map.ahc == null) return;
      const ahc = String(cells[map.ahc].textContent || "").trim();
      if (!/^\d+$/.test(ahc)) return;
      const huid = map.huid != null ? String(cells[map.huid].textContent || "").trim() : "";
      const weight = map.weight != null ? String(cells[map.weight].textContent || "").trim() : "";
      let data = null;
      try {
        data = dt ? dt.row(tr).data() : null;
      } catch {
        data = null;
      }
      out.push({ ahc, huid, weight, data, tr });
    });
    return out;
  }

  function shownWeight(ahc) {
    const row = readDetails().find((r) => String(r.ahc) === String(ahc));
    return row ? row.weight : null;
  }

  async function waitQuiet(maxMs) {
    const $ = window.jQuery;
    const start = Date.now();
    await sleep(80);
    let quietSince = 0;
    while (Date.now() - start < maxMs) {
      const active = $ && typeof $.active === "number" ? $.active : 0;
      if (!active) {
        if (!quietSince) quietSince = Date.now();
        if (Date.now() - quietSince > 180) return;
      } else quietSince = 0;
      await sleep(60);
    }
  }

  async function reloadDetails() {
    const table = findDetailsTable();
    const $ = window.jQuery;
    if (!table || !$ || !$.fn || !$.fn.dataTable || !$.fn.dataTable.isDataTable(table)) return;
    try {
      $(table).DataTable().ajax.reload(null, false);
    } catch {
      try {
        $(table).DataTable().draw(false);
      } catch {
        /* ignore */
      }
    }
    await waitQuiet(4000);
    await sleep(150);
  }

  function looksWriteUrl(url) {
    const u = String(url || "");
    if (!u || /^(#|javascript:)/i.test(u)) return false;
    if (/\.(js|css|png|jpe?g|gif|svg|woff2?)(\?|$)/i.test(u)) return false;
    if (/dataTables|jquery|bootstrap|buttons\./i.test(u)) return false;
    if (/save|update|edit/i.test(u)) return true;
    return false;
  }

  function absUrl(url) {
    try {
      return new URL(url, location.href).href;
    } catch {
      return "";
    }
  }

  function collectSources() {
    const blobs = [];
    const push = (name, src) => {
      const text = String(src || "");
      if (!text || text.length > 80000) return;
      if (!/weight|ahc|huid|article/i.test(text)) return;
      if (!/save|update|edit/i.test(text)) return;
      blobs.push({ name, src: text });
    };

    const $ = window.jQuery;
    try {
      if ($ && $.fn && $.fn.dataTable) {
        $("table").each(function () {
          try {
            if (!$.fn.dataTable.isDataTable(this)) return;
            const settings = $(this).DataTable().settings()[0];
            (settings.aoColumns || []).forEach((col, i) => {
              push(`col${i}`, `${col.sTitle || ""} ${col.mRender || ""} ${col.render || ""} ${col.sDefaultContent || ""}`);
            });
            const ajax = settings.ajax;
            if (ajax && typeof ajax !== "string") push("ajax", `${ajax.url || ""} ${ajax.data || ""}`);
          } catch {
            /* ignore */
          }
        });
      }
    } catch {
      /* ignore */
    }

    document.querySelectorAll("script:not([src])").forEach((s, i) => push(`inline${i}`, s.textContent || ""));

    const names = Object.getOwnPropertyNames(window);
    for (const name of names) {
      if (!/save|update|edit/i.test(name)) continue;
      let fn;
      try {
        fn = window[name];
      } catch {
        continue;
      }
      if (typeof fn !== "function") continue;
      let src = "";
      try {
        src = Function.prototype.toString.call(fn);
      } catch {
        src = "";
      }
      push(name, src);
    }
    return blobs;
  }

  async function collectRemoteSources() {
    const blobs = [];
    const srcs = Array.from(document.querySelectorAll("script[src]"))
      .map((s) => s.src)
      .filter((src) => {
        try {
          const u = new URL(src, location.href);
          return u.origin === location.origin && !/\.min\.js(\?|$)/i.test(u.pathname);
        } catch {
          return false;
        }
      })
      .slice(0, 12);
    await Promise.all(
      srcs.map(async (src) => {
        try {
          const res = await fetch(src, { credentials: "include", cache: "force-cache" });
          if (!res.ok) return;
          const text = await res.text();
          if (!/save|update/i.test(text) || !/weight|ahc|huid/i.test(text)) return;
          blobs.push({ name: src, src: text.slice(0, 80000) });
        } catch {
          /* ignore */
        }
      })
    );
    return blobs;
  }

  function urlsIn(src) {
    const found = [];
    const re = /['"`]([^'"`\s]{3,180})['"`]/g;
    let m;
    while ((m = re.exec(src))) {
      if (looksWriteUrl(m[1])) found.push(m[1]);
    }
    const post = src.match(/\$\.post\(\s*['"`]([^'"`]+)['"`]/i);
    if (post && looksWriteUrl(post[1])) found.push(post[1]);
    return [...new Set(found)];
  }

  function parseDataPairs(src) {
    const m = src.match(/data\s*:\s*\{([\s\S]{0,800}?)\}/);
    if (!m) return [];
    const pairs = [];
    const re = /["']?([A-Za-z_][A-Za-z0-9_]*)["']?\s*:\s*([A-Za-z_][A-Za-z0-9_]*|['"][^'"]{0,40}['"]|\d+\.?\d*)/g;
    let mm;
    while ((mm = re.exec(m[1]))) pairs.push({ key: mm[1], expr: mm[2] });
    return pairs;
  }

  function exprValue(expr, ctx) {
    if (/^['"]/.test(expr)) return expr.slice(1, -1);
    if (/^\d+(\.\d+)?$/.test(expr)) return expr;
    const n = expr.toLowerCase();
    if (/weight|artwt|gms|wt$/.test(n) && !/id$/.test(n)) return ctx.weight;
    if (/ahc/.test(n)) return ctx.ahc;
    if (/huid/.test(n)) return ctx.huid;
    if (/job/.test(n)) return ctx.jobNo;
    if (/request/.test(n)) return ctx.requestNo;
    if (ctx.data && typeof ctx.data === "object" && !Array.isArray(ctx.data)) {
      for (const [k, v] of Object.entries(ctx.data)) {
        if (String(k).toLowerCase() === n) return v;
      }
    }
    return undefined;
  }

  function buildPayload(pairs, ctx) {
    const data = {};
    if (!pairs.length) {
      if (ctx.data && typeof ctx.data === "object" && !Array.isArray(ctx.data)) {
        for (const [k, v] of Object.entries(ctx.data)) {
          if (v == null || typeof v === "object") continue;
          data[k] = /weight|gms|wt$/i.test(k) && !/id$/i.test(k) ? ctx.weight : v;
        }
      }
      data.ahcTag = ctx.ahc;
      data.AHC_Tag = ctx.ahc;
      data.huid = ctx.huid;
      data.HUID = ctx.huid;
      data.jobNo = ctx.jobNo;
      data.requestNo = ctx.requestNo;
      data.weight = ctx.weight;
      data.articleWeight = ctx.weight;
      return data;
    }
    for (const pair of pairs) {
      const value = exprValue(pair.expr, ctx);
      if (value == null) return null;
      data[pair.key] = value;
    }
    return data;
  }

  function postForm(url, data) {
    const $ = window.jQuery;
    const target = absUrl(url);
    if (!target || !$) return Promise.resolve({ ok: false, resp: "no-jquery" });
    return new Promise((resolve) => {
      $.ajax({
        url: target,
        type: "POST",
        data,
        complete: (xhr) => {
          resolve({
            ok: xhr && xhr.status >= 200 && xhr.status < 300,
            status: xhr ? xhr.status : 0,
            resp: xhr ? String(xhr.responseText || "").slice(0, 180) : "",
          });
        },
      });
    });
  }

  function primeInputs(src, ctx) {
    const holder = document.createElement("div");
    holder.style.display = "none";
    const add = (id) => {
      if (!id || holder.querySelector(`[id="${CSS.escape(id)}"]`)) return;
      const input = document.createElement("input");
      input.id = id;
      input.value = String(ctx.weight);
      holder.appendChild(input);
    };
    let m;
    const plain = /getElementById\(\s*['"]([^'"]+)['"]\s*\)|\$\(\s*['"]#([^'"]+)['"]\s*\)/g;
    while ((m = plain.exec(src))) add(m[1] || m[2]);
    const dynamic = /\$\(\s*['"]#([^'"]+)['"]\s*\+\s*([A-Za-z_][A-Za-z0-9_]*)/g;
    while ((m = dynamic.exec(src))) {
      const tail = exprValue(m[2], ctx);
      if (tail != null) add(m[1] + tail);
    }
    if (!holder.childNodes.length) return () => {};
    document.body.appendChild(holder);
    return () => holder.remove();
  }

  function ctxFor(row, weight, jr) {
    return {
      ahc: row.ahc,
      huid: row.huid,
      weight: String(weight),
      jobNo: jr.jobNo,
      requestNo: jr.requestNo,
      data: row.data,
    };
  }

  async function confirmed(ahc, weight) {
    await waitQuiet(2500);
    await reloadDetails();
    return same(shownWeight(ahc), weight);
  }

  async function updateAll(rows) {
    window.alert = () => {};
    window.confirm = () => true;
    const jr = jobRequest();
    const wanted = new Map();
    for (const row of rows || []) {
      const ahc = String(row?.ahcTag ?? "").trim();
      const weight = row?.weight;
      if (!ahc || weight == null || weight === "" || num(weight) == null || num(weight) < 0) continue;
      wanted.set(ahc, String(weight));
    }
    if (!wanted.size) return { ok: false, error: "Excel me valid AHC + weight nahi." };

    progress("Saved Details rows padh rahe hain…");
    let details = readDetails();
    if (!details.length) {
      await sleep(200);
      details = readDetails();
    }
    if (!details.length) return { ok: false, error: "Article Weight Details me koi saved row nahi." };

    const todo = [];
    let unchanged = 0;
    const missing = [];
    for (const [ahc, weight] of wanted) {
      const row = details.find((r) => String(r.ahc) === ahc);
      if (!row) {
        missing.push(ahc);
        continue;
      }
      if (same(row.weight, weight)) {
        unchanged++;
        continue;
      }
      todo.push({ row, weight });
    }
    if (!todo.length) {
      return {
        ok: true,
        updated: 0,
        unchanged,
        failed: [],
        missing,
        error: missing.length ? "" : "Details me yeh weights pehle se Excel jaisi hain.",
      };
    }

    progress("Page ka Save call dhoondh rahe hain…");
    const sources = collectSources().concat(await collectRemoteSources());
    const fnByName = new Map();
    for (const name of Object.getOwnPropertyNames(window)) {
      if (!/save|update|edit/i.test(name)) continue;
      try {
        if (typeof window[name] === "function") fnByName.set(name, window[name]);
      } catch {
        /* ignore */
      }
    }

    const posts = [];
    const calls = [];
    for (const blob of sources) {
      const pairs = parseDataPairs(blob.src);
      for (const url of urlsIn(blob.src)) {
        posts.push({ url, pairs, name: blob.name });
      }
      if (fnByName.has(blob.name)) calls.push({ name: blob.name, fn: fnByName.get(blob.name), src: blob.src });
    }

    const sample = todo[0];
    const sampleCtx = ctxFor(sample.row, sample.weight, jr);
    let winner = null;

    for (const post of posts.slice(0, 6)) {
      const data = buildPayload(post.pairs, sampleCtx);
      if (!data) continue;
      progress(`Update try ${sample.row.ahc} → ${sample.weight} (${post.url.split("/").pop()})…`);
      await postForm(post.url, data);
      if (await confirmed(sample.row.ahc, sample.weight)) {
        winner = { kind: "post", post };
        break;
      }
    }

    if (!winner) {
      for (const call of calls.slice(0, 6)) {
        const cleanup = primeInputs(call.src, sampleCtx);
        try {
          progress(`Page function ${call.name} se AHC ${sample.row.ahc} update…`);
          const ret = call.fn(sample.row.ahc, sample.weight, sample.row.huid, jr.jobNo, jr.requestNo);
          await Promise.resolve(ret).catch(() => {});
        } catch {
          /* next */
        } finally {
          cleanup();
        }
        if (await confirmed(sample.row.ahc, sample.weight)) {
          winner = { kind: "fn", call };
          break;
        }
      }
    }

    if (!winner) {
      return {
        ok: false,
        updated: 0,
        unchanged,
        failed: todo.map((t) => t.row.ahc),
        missing,
        error:
          "Saved weight update nahi hui. Is page ke Save function ne Details ka number nahi badla. " +
          (posts.length || calls.length
            ? `Dekhe gaye calls: ${[...new Set([...posts.map((p) => p.url), ...calls.map((c) => c.name)])].slice(0, 4).join(", ")}`
            : "Page source me koi weight-save call nahi mila."),
      };
    }

    let updated = 1;
    const failed = [];
    for (let i = 1; i < todo.length; i++) {
      const item = todo[i];
      const ctx = ctxFor(item.row, item.weight, jr);
      progress(`Updating AHC ${item.row.ahc} → ${item.weight} (${i + 1}/${todo.length})…`);
      if (winner.kind === "post") {
        const data = buildPayload(winner.post.pairs, ctx);
        if (!data) {
          failed.push(item.row.ahc);
          continue;
        }
        await postForm(winner.post.url, data);
      } else {
        const cleanup = primeInputs(winner.call.src, ctx);
        try {
          const ret = winner.call.fn(item.row.ahc, item.weight, item.row.huid, jr.jobNo, jr.requestNo);
          await Promise.resolve(ret).catch(() => {});
        } catch {
          failed.push(item.row.ahc);
          cleanup();
          continue;
        }
        cleanup();
      }
      if (await confirmed(item.row.ahc, item.weight)) updated++;
      else failed.push(item.row.ahc);
    }

    return {
      ok: updated > 0,
      updated,
      unchanged,
      failed,
      missing,
      via: winner.kind === "post" ? winner.post.url : winner.call.name,
    };
  }

  window.__SHRIJA_UPDATE_API__ = { __v: 1, updateAll };
})();
