// Shrija Weight Capture — toggle panel + MAIN-world hooks (dialogs + serial block)
// Client ko dene se pehle LICENSE_SERVER apne HTTPS address par badlo, aur manifest host_permissions mein wahi origin add karo.
const LICENSE_SERVER = "https://shrija-weight-license-production.up.railway.app";
const LICENSE_PUBLIC_KEY_B64 = "MCowBQYDK2VwAyEAoNJP6B5NXU7p1Z18aUNJo35cKbZ1wYJ8h98zPXp/YWg=";

let licensePublicKeyPromise;
function licensePublicKey() {
  if (!licensePublicKeyPromise) {
    const raw = Uint8Array.from(atob(LICENSE_PUBLIC_KEY_B64), (c) => c.charCodeAt(0));
    licensePublicKeyPromise = crypto.subtle.importKey("spki", raw, { name: "Ed25519" }, false, ["verify"]);
  }
  return licensePublicKeyPromise;
}

async function checkRemoteLicense(key, installId, label) {
  let res;
  try {
    const response = await fetch(LICENSE_SERVER + "/api/v1/check", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        key: String(key || "").trim().toUpperCase(),
        installId: String(installId || ""),
        label: String(label || "").slice(0, 80),
      }),
    });
    res = await response.json();
  } catch {
    return { ok: false, reason: "server", message: "License server nahi mil raha. Panel wala computer on hona chahiye." };
  }
  if (!res?.payload || !res?.sig) {
    return { ok: false, reason: "server", message: "License server ka jawab adhoora hai." };
  }
  try {
    const sig = Uint8Array.from(atob(res.sig), (c) => c.charCodeAt(0));
    const valid = await crypto.subtle.verify(
      { name: "Ed25519" },
      await licensePublicKey(),
      sig,
      new TextEncoder().encode(res.payload)
    );
    if (!valid) return { ok: false, reason: "server", message: "License jawab verify nahi hua." };
    const data = JSON.parse(res.payload);
    if (data.installId !== String(installId || "") || data.key !== String(key || "").trim().toUpperCase()) {
      return { ok: false, reason: "server", message: "License jawab is computer ka nahi hai." };
    }
    return data;
  } catch {
    return { ok: false, reason: "server", message: "License verify fail." };
  }
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id || !tab.url) return;
  if (!/huid\.manakonline\.in\/MANAK\/UID_WeighingForm/i.test(tab.url)) {
    return;
  }
  try {
    await chrome.tabs.sendMessage(tab.id, { type: "SHRIJA_TOGGLE_PANEL" });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      files: ["content/page-hook.js", "content/page-delete.js"],
    });
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ["lib/xlsx.full.min.js", "content/content.js"],
    });
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ["content/content.css"],
    });
    await chrome.tabs.sendMessage(tab.id, { type: "SHRIJA_TOGGLE_PANEL" });
  }
});

function installPageHooks() {
  if (window.__SHRIJA_PAGE_HOOK__) return true;
  window.__SHRIJA_PAGE_HOOK__ = true;

  window.alert = () => {};
  window.confirm = () => true;
  window.prompt = (_m, d) => (d == null ? "" : String(d));

  try {
    if (navigator.serial) {
      const blocked = () =>
        Promise.reject(new DOMException("Blocked by Shrija Weight Capture", "NotAllowedError"));
      navigator.serial.requestPort = blocked;
      navigator.serial.getPorts = async () => [];
    }
  } catch (_) {}

  try {
    if (window.jQuery) {
      const $ = window.jQuery;
      if ($.alert) $.alert = () => {};
    }
  } catch (_) {}

  return true;
}

/**
 * Fill every Capture Scan-weight field in one pass, then fire every row Save
 * while the portal's table refresh is frozen. Save's redraw is what was
 * wiping every tag except one.
 */
async function fillAllBypassSave(rows) {
  const weightByAhc = new Map();
  for (const row of rows || []) {
    const ahc = String(row?.ahcTag ?? "").trim();
    if (!ahc) continue;
    const weight = row.weight;
    if (weight == null || weight === "" || !Number.isFinite(Number(weight)) || Number(weight) < 0) continue;
    weightByAhc.set(ahc, String(weight));
  }
  if (!weightByAhc.size) return { ok: false, error: "Excel me koi valid AHC + weight nahi." };

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  window.alert = () => {};
  window.confirm = () => true;
  window.prompt = (_m, d) => (d == null ? "" : String(d));

  function findCaptureTable() {
    const tables = Array.from(document.querySelectorAll("table"));
    for (const table of tables) {
      const headers = Array.from(table.querySelectorAll("thead th, tr th")).map((th) =>
        (th.textContent || "").trim().toLowerCase()
      );
      const hasAhc = headers.some((h) => h.includes("ahc"));
      const hasSave = headers.some((h) => h.includes("save"));
      const hasWeight = headers.some((h) => h.includes("weight"));
      if (hasAhc && hasSave && (hasWeight || table.querySelector("tbody input"))) return table;
    }
    return null;
  }

  function headerMap(table) {
    const headerRow =
      table.querySelector("thead tr") ||
      Array.from(table.querySelectorAll("tr")).find((tr) => tr.querySelector("th"));
    const map = {};
    if (!headerRow) return map;
    Array.from(headerRow.children).forEach((cell, i) => {
      const h = (cell.textContent || "").trim().toLowerCase().replace(/\s+/g, " ");
      if (h.includes("ahc")) map.ahc = i;
      else if (h.includes("weight")) map.weight = i;
      else if (h.includes("save")) map.save = i;
      else if (h.includes("s no") || h === "s.no." || h.includes("serial")) map.sno = i;
    });
    return map;
  }

  function expand(table) {
    try {
      const $ = window.jQuery;
      if ($ && $.fn && $.fn.dataTable && $.fn.dataTable.isDataTable(table)) {
        const dt = $(table).DataTable();
        try {
          dt.settings()[0]._iDisplayLength = -1;
        } catch (_) {}
        dt.page.len(-1).draw(false);
        const $len = $(table).closest(".dataTables_wrapper").find("select[name$=_length]");
        if ($len.length) {
          if (!$len.find('option[value="-1"]').length) $len.append('<option value="-1">All</option>');
          $len.val("-1");
        }
        return true;
      }
    } catch (_) {}
    const wrap = table.closest(".dataTables_wrapper");
    const lengthSelect = wrap && wrap.querySelector(".dataTables_length select, select[name$='_length']");
    if (!lengthSelect) return false;
    if (![...lengthSelect.options].some((o) => o.value === "-1")) {
      const opt = document.createElement("option");
      opt.value = "-1";
      opt.textContent = "All";
      lengthSelect.appendChild(opt);
    }
    lengthSelect.value = "-1";
    lengthSelect.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  function rowAhc(tr, map) {
    const cells = Array.from(tr.querySelectorAll("td"));
    let ahc = "";
    if (map.ahc != null && cells[map.ahc]) ahc = (cells[map.ahc].textContent || "").trim();
    if (!ahc || !/^\d+$/.test(ahc)) {
      for (let i = 0; i < Math.min(cells.length, 4); i++) {
        const v = (cells[i].textContent || "").trim();
        if (/^\d{1,8}$/.test(v) && i !== map.sno) {
          ahc = v;
          break;
        }
      }
    }
    return ahc;
  }

  function collectJobs(table, done) {
    const map = headerMap(table);
    const jobs = [];
    const bodyRows = Array.from(table.querySelectorAll("tbody tr")).filter((tr) => {
      const text = (tr.textContent || "").trim().toLowerCase();
      return text && !text.includes("no data available") && tr.querySelectorAll("td").length > 1;
    });
    for (const tr of bodyRows) {
      const ahc = rowAhc(tr, map);
      if (!ahc || done.has(ahc) || !weightByAhc.has(ahc)) continue;
      const cells = Array.from(tr.querySelectorAll("td"));
      const input =
        (map.weight != null && cells[map.weight] && cells[map.weight].querySelector("input, textarea")) ||
        tr.querySelector("input, textarea");
      const btn =
        (map.save != null && cells[map.save] && cells[map.save].querySelector("button, a, input[type='button'], input[type='submit']")) ||
        Array.from(tr.querySelectorAll("button, a, input[type='button'], input[type='submit']")).find((el) =>
          /save/i.test(`${el.textContent || ""} ${el.value || ""} ${el.className || ""}`)
        );
      if (!input || !btn) continue;
      jobs.push({ ahc, input, btn, weight: weightByAhc.get(ahc) });
    }
    return jobs;
  }

  const valueDesc = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
  const locked = new Set();
  const restoreFns = [];

  function lockValues() {
    if (!valueDesc || !valueDesc.set || !valueDesc.configurable) return;
    const origSet = valueDesc.set;
    const origGet = valueDesc.get;
    Object.defineProperty(HTMLInputElement.prototype, "value", {
      configurable: true,
      enumerable: valueDesc.enumerable,
      get() {
        return origGet.call(this);
      },
      set(v) {
        if (locked.has(this) && !String(v == null ? "" : v).trim()) return;
        origSet.call(this, v);
      },
    });
    restoreFns.push(() => {
      Object.defineProperty(HTMLInputElement.prototype, "value", valueDesc);
    });
  }

  function freezeRefresh() {
    const $ = window.jQuery;
    try {
      const proto = $ && $.fn && $.fn.dataTable && $.fn.dataTable.Api && $.fn.dataTable.Api.prototype;
      if (proto && proto.ajax && typeof proto.ajax.reload === "function") {
        const orig = proto.ajax.reload;
        proto.ajax.reload = function () {
          return this;
        };
        restoreFns.push(() => {
          proto.ajax.reload = orig;
        });
      }
    } catch (_) {}

    const origFocus = HTMLElement.prototype.focus;
    HTMLElement.prototype.focus = function () {
      if (this instanceof HTMLInputElement || this instanceof HTMLTextAreaElement) return;
      return origFocus.apply(this, arguments);
    };
    restoreFns.push(() => {
      HTMLElement.prototype.focus = origFocus;
    });

    const stopFieldEvent = (e) => {
      if (e.target && locked.has(e.target)) e.stopImmediatePropagation();
    };
    document.addEventListener("input", stopFieldEvent, true);
    document.addEventListener("change", stopFieldEvent, true);
    restoreFns.push(() => {
      document.removeEventListener("input", stopFieldEvent, true);
      document.removeEventListener("change", stopFieldEvent, true);
    });
  }

  function applyAll(jobs) {
    for (const job of jobs) {
      locked.add(job.input);
      const proto = Object.getPrototypeOf(job.input);
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(job.input, job.weight);
      else job.input.value = job.weight;
      try {
        job.input.setAttribute("value", job.weight);
      } catch (_) {}
    }
  }

  function fireAll(jobs) {
    let fired = 0;
    for (const job of jobs) {
      const btn = job.btn;
      try {
        if (btn.tagName === "BUTTON" || btn.tagName === "INPUT") {
          const t = (btn.getAttribute("type") || "").toLowerCase();
          if (t === "submit") btn.setAttribute("type", "button");
        }
        btn.click();
        fired++;
      } catch (_) {
        try {
          btn.click();
          fired++;
        } catch (_) {}
      }
    }
    return fired;
  }

  async function waitQuiet(maxMs) {
    const $ = window.jQuery;
    const start = Date.now();
    await sleep(100);
    let quietSince = 0;
    while (Date.now() - start < maxMs) {
      const active = $ && typeof $.active === "number" ? $.active : 0;
      if (!active) {
        if (!quietSince) quietSince = Date.now();
        if (Date.now() - quietSince > 220) return;
      } else {
        quietSince = 0;
      }
      await sleep(70);
    }
  }

  function stillPending() {
    const table = findCaptureTable();
    if (!table) return [];
    const map = headerMap(table);
    const left = [];
    for (const tr of table.querySelectorAll("tbody tr")) {
      const ahc = rowAhc(tr, map);
      if (ahc && weightByAhc.has(ahc) && tr.querySelector("input, textarea")) left.push(ahc);
    }
    return left;
  }

  const done = new Set();
  let filled = 0;
  let fired = 0;

  try {
    let table = findCaptureTable();
    if (!table) return { ok: false, error: "Articles Weight Capture table nahi mili." };

    expand(table);
    await sleep(350);
    table = findCaptureTable() || table;
    expand(table);
    await sleep(200);

    lockValues();
    freezeRefresh();

    const runVisible = () => {
      const live = findCaptureTable() || table;
      const jobs = collectJobs(live, done);
      if (!jobs.length) return 0;
      applyAll(jobs);
      filled += jobs.length;
      fired += fireAll(jobs);
      jobs.forEach((j) => done.add(j.ahc));
      return jobs.length;
    };

    runVisible();

    if (done.size < weightByAhc.size) {
      const wrap = (findCaptureTable() || table).closest(".dataTables_wrapper") || document;
      const first = wrap.querySelector(".dataTables_paginate .paginate_button.first:not(.disabled)");
      if (first) {
        first.click();
        await sleep(250);
        runVisible();
      }
      let emptyPages = 0;
      for (let page = 0; page < 80 && done.size < weightByAhc.size; page++) {
        const next = wrap.querySelector(".dataTables_paginate .paginate_button.next:not(.disabled)");
        if (!next) break;
        next.click();
        await sleep(220);
        if (!runVisible()) {
          emptyPages++;
          if (emptyPages >= 2) break;
        } else {
          emptyPages = 0;
        }
      }
    }

    await waitQuiet(8000);

    for (const fn of restoreFns.splice(0)) {
      try {
        fn();
      } catch (_) {}
    }

    try {
      const $ = window.jQuery;
      const live = findCaptureTable();
      if ($ && live && $.fn.dataTable && $.fn.dataTable.isDataTable(live)) {
        $(live).DataTable().ajax.reload(null, false);
        await waitQuiet(5000);
      }
    } catch (_) {}

    const left = stillPending().filter((ahc) => done.has(ahc));
    const saved = [...done].filter((ahc) => !left.includes(ahc)).length;
    return {
      ok: filled > 0,
      filled,
      fired,
      saved,
      left,
      wanted: weightByAhc.size,
    };
  } catch (err) {
    for (const fn of restoreFns.splice(0)) {
      try {
        fn();
      } catch (_) {}
    }
    return { ok: false, error: String(err && err.message ? err.message : err), filled, fired };
  }
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const tabId = sender.tab?.id;

  if (msg?.type === "SHRIJA_LICENSE_CHECK") {
    checkRemoteLicense(msg.key, msg.installId, msg.label)
      .then((result) => sendResponse(result))
      .catch((err) => sendResponse({ ok: false, reason: "server", message: String(err) }));
    return true;
  }

  if (msg?.type === "SHRIJA_INSTALL_AUTO_DIALOG") {
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: "MAIN",
        func: installPageHooks,
      })
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type === "SHRIJA_EXPAND_DATATABLE") {
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: "MAIN",
        func: () => {
          try {
            const $ = window.jQuery;
            if (!$ || !$.fn || !$.fn.dataTable) return { ok: false, reason: "no-datatables" };

            const tables = Array.from(document.querySelectorAll("table"));
            for (const table of tables) {
              if (!$.fn.dataTable.isDataTable(table)) continue;
              const headerText = Array.from(table.querySelectorAll("thead th, tr th"))
                .map((th) => (th.textContent || "").trim().toLowerCase())
                .join(" ");
              const looksCapture =
                headerText.includes("ahc") ||
                table.querySelector('input[placeholder*="Scan weight" i], input[placeholder*="weight" i]');
              if (!looksCapture) continue;

              const dt = $(table).DataTable();
              // Force every row into the DOM (not just page size 5/10)
              try {
                dt.settings()[0]._iDisplayLength = -1;
              } catch (_) {}
              dt.page.len(-1);
              dt.draw(false);

              const $len = $(table).closest(".dataTables_wrapper").find("select[name$=_length]");
              if ($len.length) {
                if (!$len.find('option[value="-1"]').length) {
                  $len.append('<option value="-1">All</option>');
                }
                $len.val("-1").trigger("change");
              }

              return {
                ok: true,
                rows: dt.rows({ search: "applied" }).count(),
                pageLen: dt.page.len(),
              };
            }
            return { ok: false, reason: "table-not-found" };
          } catch (err) {
            return { ok: false, reason: String(err) };
          }
        },
      })
      .then((results) => sendResponse(results?.[0]?.result || { ok: false }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type === "SHRIJA_FILL_BYPASS_SAVE") {
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    const rows = Array.isArray(msg.rows) ? msg.rows : [];
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: "MAIN",
        func: fillAllBypassSave,
        args: [rows],
      })
      .then((results) => sendResponse(results?.[0]?.result || { ok: false }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type === "SHRIJA_UPDATE_SAVED") {
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    const rows = Array.isArray(msg.rows) ? msg.rows : [];
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: "MAIN",
        files: ["content/page-update.js"],
      })
      .then(() =>
        chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: async (list) => {
            if (!window.__SHRIJA_UPDATE_API__?.updateAll) {
              return { ok: false, error: "update-api-missing" };
            }
            return await window.__SHRIJA_UPDATE_API__.updateAll(list);
          },
          args: [rows],
        })
      )
      .then((results) => sendResponse(results?.[0]?.result || { ok: false }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg?.type === "SHRIJA_DELETE_SAVED") {
    if (!tabId) {
      sendResponse({ ok: false });
      return;
    }
    const filterAhcs = Array.isArray(msg.filterAhcs) ? msg.filterAhcs : null;
    chrome.scripting
      .executeScript({
        target: { tabId },
        world: "MAIN",
        files: ["content/page-delete.js"],
      })
      .then(() =>
        chrome.scripting.executeScript({
          target: { tabId },
          world: "MAIN",
          func: async (filter) => {
            if (!window.__SHRIJA_DELETE_API__?.deleteAll) {
              return { ok: false, error: "delete-api-missing" };
            }
            return await window.__SHRIJA_DELETE_API__.deleteAll(filter);
          },
          args: [filterAhcs],
        })
      )
      .then((results) => sendResponse(results?.[0]?.result || { ok: false }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
});
